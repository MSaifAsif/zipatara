package com.sample;

import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;

public class ApartmentDoc {

    private String documentId;
    private MapWritable jsonDoc;

    public ApartmentDoc(String documentId, MapWritable jsonDoc) {

        this.documentId = documentId;
        this.jsonDoc = jsonDoc;
    }

    public void removeField(String fieldName) {
        try {
            jsonDoc.remove(new Text(fieldName));
        } catch (Exception ex) {

        }
    }

    public String getDocumentId() {
        return documentId;
    }

    public MapWritable getJsonDoc() {
        return jsonDoc;
    }
}
