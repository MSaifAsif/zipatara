package com.sample;

import org.apache.hadoop.io.Text;

public class RemovalTask {

}
