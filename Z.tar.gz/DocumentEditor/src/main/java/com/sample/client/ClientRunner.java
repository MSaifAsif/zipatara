package com.sample.client;

import com.sample.one.mappers.DocumentUpdaterMapper;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.elasticsearch.hadoop.mr.EsInputFormat;
import org.elasticsearch.hadoop.mr.EsOutputFormat;

public class ClientRunner extends Configured implements Tool {

    @Override
    public int run(String[] args) throws Exception {
        Configuration conf = new Configuration();
//        conf.set("es.query", "?q=me*");
        conf.set("es.resource.read", "apartments_v1");
        conf.set("es.resource.write", "changed/apartments_v2");
        conf.set("es.nodes", "172.17.0.2:9200");
        Job job = new Job(conf);
        job.setMapOutputKeyClass(Text.class);

        job.setMapperClass(DocumentUpdaterMapper.class);
        job.setJarByClass(DocumentUpdaterMapper.class);

        job.setInputFormatClass(EsInputFormat.class);
        job.setOutputFormatClass(EsOutputFormat.class);
        job.setMapOutputValueClass(MapWritable.class);
        job.setOutputValueClass(NullWritable.class);

        job.waitForCompletion(true);
        return 0;
    }

    public static void main(String[] args) throws Exception {
        int rc = ToolRunner.run(new ClientRunner(), args);
        System.exit(rc);
    }
}
