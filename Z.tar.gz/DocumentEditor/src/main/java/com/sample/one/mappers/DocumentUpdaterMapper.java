package com.sample.one.mappers;

import com.sample.ApartmentDoc;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DocumentUpdaterMapper extends Mapper<Text, MapWritable, Text, MapWritable> {

    private static final Logger logger = Logger.getLogger(DocumentUpdaterMapper.class);

    @Override
    protected void map(Text key, MapWritable value, Context context) throws IOException, InterruptedException {

        ApartmentDoc esDocument = new ApartmentDoc(key.toString(), value);

        logger.info("GOt Document: " + esDocument.getDocumentId());
        System.out.println("GOt Document: " + esDocument.getDocumentId());
        System.out.println(esDocument.getJsonDoc().toString());

        esDocument = performOp(esDocument);
        context.write(key, esDocument.getJsonDoc());

    }

    private static ApartmentDoc performOp(ApartmentDoc esDocument) {
        List<String> removeFields = new ArrayList<>();
        for (Map.Entry<Writable, Writable> entry : esDocument.getJsonDoc().entrySet()) {

            if (entry.getValue().toString().startsWith("2016") || entry.getValue().toString().startsWith("16")) {
                removeFields.add(entry.getKey().toString());
            }
        }
        for (String field : removeFields) {
            System.out.println("\t\t " + field);
        }
        return esDocument;
    }
}
