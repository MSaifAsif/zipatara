package com.etilize.analytics;

import org.apache.hadoop.util.ToolRunner;

import com.etilize.analytics.mapreduce.ESMapReduce;
//import org.apache.hadoop.util.ToolRunner;
//
//import com.etilize.analytics.mapreduce.ESMapReduce;

public class ElasticHadoopDriver {
    public static void main(String[] args) throws Exception {
        int exitCode = ToolRunner.run(new ESMapReduce(), args);
        System.exit(exitCode);
    }
}
