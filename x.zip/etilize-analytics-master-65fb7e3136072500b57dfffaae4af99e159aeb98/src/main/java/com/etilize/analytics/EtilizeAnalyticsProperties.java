package com.etilize.analytics;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.etilize.commons.AbstractProperties;

/**
 * <p>
 * This class use etilizeanalytics.properties file to read properties that can
 * be used in this project
 * </p>
 * <br/>
 * <p>
 * Property file path should be
 * /apps/EtilizeAnalytics/EtilizeAnalytics.properties
 * </p>
 * 
 * @version 0.1.0
 */

public class EtilizeAnalyticsProperties extends AbstractProperties {

    private static Logger logger = LoggerFactory.getLogger(EtilizeAnalyticsProperties.class);
    private static EtilizeAnalyticsProperties INSTANCE;
    // / private static String filePath =
    // System.getProperty("etilizeanalytics.properties.file.path");
    private static String filePath = "/apps/EtilizeAnalytics/EtilizeAnalytics.properties";
    // private static String fileName = "EtilizeAnalytics.properties";
    private static final String PREFIX = "EtilizeAnalytics";
    private final static String VERSION = "1.0.0 (Build 16-01-2013)";

    private EtilizeAnalyticsProperties() {
        try {
            // logger =
            // LoggerFactory.getLogger(EtilizeAnalyticsProperties.class);
            logger.info("File path : " + filePath);
            // System.out.println(filePath);
            resolveReferenceProperties();
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    // TODO this function will not replace properties having recursive
    // reference.
    private void resolveReferenceProperties() throws Exception {
        final String propertyIdentifierPattern = "(?<=\\$\\{).[a-zA-Z0-9.]*(?=\\})";
        Pattern pattern = Pattern.compile(propertyIdentifierPattern);
        Map<String, String> allProperties = getProperties();
        for (Entry<String, String> property : allProperties.entrySet()) {
            String key = property.getKey();
            String value = property.getValue();
            Matcher matcher = pattern.matcher(value);
            while (matcher.find()) {
                String propertyName = matcher.group();
                String referencedPropertyValue = getPropertyValue(propertyName.replace(PREFIX + ".", ""));
                logger.info("Key : " + key + " Value : " + value);
                if (referencedPropertyValue != null) {
                    value = value.replace("${" + propertyName + "}", referencedPropertyValue);
                } else {
                    throw new Exception(propertyName + " not found in property file.");
                }
            }
            allProperties.put(key, value);
        }
        updateProperties(allProperties);
    }

    public synchronized static EtilizeAnalyticsProperties getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new EtilizeAnalyticsProperties();
        }
        return INSTANCE;
    }

    public static String getRequiredProperty(String property) {
        return getInstance().getRequiredPropertyValue(property);
    }

    public static String getProperty(String property) {
        return getInstance().getPropertyValue(property);
    }

    public static String getProperty(String property, String defaultValue) throws Exception {
        return getInstance().getPropertyValue(property, defaultValue);
    }

    public static int getIntProperty(String property, int defaultValue) {
        return getInstance().getIntPropertyValue(property, defaultValue);
    }

    public static boolean getBooleanProperty(String property, boolean defaultValue) {
        return getInstance().getBooleanPropertyValue(property, defaultValue);
    }

    public static void initialize() {
        getInstance();
    }

    public static void setProperties(Properties props) {
        if (!isInitialized()) {
            AbstractProperties.setProperties(props);
        } else {
            throw new IllegalStateException(INSTANCE.getPrefix() + " Properties have already been initialized");
        }
    }

    public static boolean isInitialized() {
        return INSTANCE != null;
    }

    protected void logMessages(List<String> messages) {
        for (String msg : messages) {
            logger.info(msg);
        }
    }

    /**
     * Default locale.
     * 
     * @return
     */
    public static Locale getDefaultLocale() {
        return new Locale("en", "US");
    }

    public String getPrefix() {
        return PREFIX;
    }

    public String getVersion() {
        return VERSION;
    }

    protected String getPropertiesPath() {
        return filePath;
    }
}