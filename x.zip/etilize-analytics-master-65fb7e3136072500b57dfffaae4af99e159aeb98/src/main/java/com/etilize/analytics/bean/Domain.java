package com.etilize.analytics.bean;

import java.util.ArrayList;
import java.util.List;

public class Domain {

    private String value;
    private long count;
    private List<Parameter> parameters;

    public List<Parameter> getParameters() {
        return parameters;
    }

    public void setParameters(List<Parameter> parameters) {
        this.parameters = parameters;
    }

    public Domain() {
        super();
        parameters = new ArrayList<Parameter>();
        // TODO Auto-generated constructor stub
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }

}
