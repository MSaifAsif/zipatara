package com.etilize.analytics.bean;

import java.util.ArrayList;
import java.util.List;

public class Parameter {

    public List<ParamValue> getFullValues() {
        return fullValues;
    }

    public void setFullValues(List<ParamValue> fullValues) {
        this.fullValues = fullValues;
    }

    public List<ParamValue> getTokenizeValues() {
        return tokenizeValues;
    }

    public void setTokenizeValues(List<ParamValue> tokenizeValues) {
        this.tokenizeValues = tokenizeValues;
    }

    private String key;
    private List<ParamValue> fullValues;
    private List<ParamValue> tokenizeValues;
    private int count;

    public Parameter() {
        super();
        fullValues = new ArrayList<ParamValue>();
        tokenizeValues = new ArrayList<ParamValue>();
        // TODO Auto-generated constructor stub
    }

    public Parameter(String key, int count) {
        super();
        this.key = key;
        fullValues = new ArrayList<ParamValue>();
        tokenizeValues = new ArrayList<ParamValue>();
        this.count = count;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public void addFullParamValue(String paramValue) {
        for (ParamValue value : fullValues) {
            if (value.getValue().equalsIgnoreCase(paramValue)) {
                value.setCount(value.getCount() + 1);
                return;
            }
        }
        ParamValue value = new ParamValue(paramValue, 1);
        fullValues.add(value);
    }

    public void addTokenizeParamValue(String paramValue) {
        for (ParamValue value : tokenizeValues) {
            if (value.getValue().equalsIgnoreCase(paramValue)) {
                value.setCount(value.getCount() + 1);
                return;
            }
        }
        ParamValue value = new ParamValue(paramValue, 1);
        tokenizeValues.add(value);
    }
}
