package com.etilize.analytics.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.etilize.analytics.EtilizeAnalyticsProperties;
import com.etilize.analytics.data.DomainInfoBean;
import com.etilize.analytics.data.DomainParameterInfoBean;
import com.etilize.commons.dao.DAOException;
import com.etilize.commons.dao.DAOUtils;
import com.etilize.commons.dao.ParameterMapping;
import com.etilize.commons.dao.ResultSetMapping;

public class DomainInfoDAO {

    public static Set<String> getAllDomains() {
        final Set<String> domains = new HashSet<String>();
        try {
            String sql = "SELECT distinct domain FROM domain_info";
            DAOUtils.executeSelect(sql, null, new ResultSetMapping() {

                public void processResultSet(ResultSet resultSet) throws SQLException {
                    while (resultSet.next()) {
                        String domain = resultSet.getString("domain");
                        domains.add(domain);
                    }
                }
            }, EtilizeAnalyticsProperties.getInstance());

        } catch (DAOException e) {
            e.printStackTrace();
        }
        return domains;
    }

    public static List<DomainParameterInfoBean> getDomainParameterScoresByDomain(final String domain) {
        final List<DomainParameterInfoBean> domainParameterScoreList = new ArrayList<DomainParameterInfoBean>();

        try {
            String sql = "SELECT * FROM domain_parameter_score WHERE domain = ?";
            DAOUtils.executeSelect(sql, new ParameterMapping() {
                public void populatePreparedStatement(PreparedStatement stmt) throws SQLException {
                    stmt.setString(1, domain);

                }
            }, new ResultSetMapping() {

                public void processResultSet(ResultSet resultSet) throws SQLException {
                    while (resultSet.next()) {

                        DomainParameterInfoBean bean = new DomainParameterInfoBean();
                        bean.setDomain(domain);
                        bean.setParameterName(resultSet.getString("parameter_name"));
                        bean.setScore(resultSet.getInt("score"));
                        // bean.setCardinality(resultSet.getInt("cardinality"));
                        bean.setStatus(resultSet.getInt("status"));
                        bean.setPattern(resultSet.getString("pattern"));

                        domainParameterScoreList.add(bean);
                    }
                }
            }, EtilizeAnalyticsProperties.getInstance());

        } catch (DAOException e) {
            e.printStackTrace();
        }
        return domainParameterScoreList;

    }

    public static void insertDomainInfo(final DomainInfoBean bean) {
        try {
            String sql = "INSERT INTO domain_info (domain) VALUES (?)";
            DAOUtils.executeInsert(sql, new ParameterMapping() {
                public void populatePreparedStatement(PreparedStatement stmt) throws SQLException {
                    stmt.setString(1, bean.getDomain());
                }
            }, EtilizeAnalyticsProperties.getInstance());

        } catch (DAOException e) {
            e.printStackTrace();
        }

    }

}
