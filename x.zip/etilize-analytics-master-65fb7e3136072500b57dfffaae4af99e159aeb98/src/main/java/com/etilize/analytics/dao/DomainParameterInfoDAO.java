package com.etilize.analytics.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.etilize.analytics.EtilizeAnalyticsProperties;
import com.etilize.analytics.data.DomainParameterInfoBean;
import com.etilize.commons.dao.DAOException;
import com.etilize.commons.dao.DAOUtils;
import com.etilize.commons.dao.ParameterMapping;
import com.etilize.commons.dao.ResultSetMapping;

import lombok.extern.log4j.Log4j;

@Log4j
public class DomainParameterInfoDAO {

    public static Set<String> getAllDomains() {
        final Set<String> domains = new HashSet<String>();
        try {
            String sql = "SELECT distinct domain FROM domain_parameter_score";
            DAOUtils.executeSelect(sql, null, new ResultSetMapping() {

                public void processResultSet(ResultSet resultSet) throws SQLException {
                    while (resultSet.next()) {
                        String domain = resultSet.getString("domain");
                        domains.add(domain);
                    }
                }
            }, EtilizeAnalyticsProperties.getInstance());

        } catch (DAOException e) {
            e.printStackTrace();
        }
        return domains;
    }

    public static HashMap<String, DomainParameterInfoBean> getAllDomainParameterScores() {
        final HashMap<String, DomainParameterInfoBean> domainParameterScoreMap = new HashMap<String, DomainParameterInfoBean>();

        try {
            String sql = "SELECT * FROM domain_parameter_score";
            DAOUtils.executeSelect(sql, null, new ResultSetMapping() {

                public void processResultSet(ResultSet resultSet) throws SQLException {
                    while (resultSet.next()) {
                        String domain = resultSet.getString("domain");
                        if (!domainParameterScoreMap.containsKey(domain)) {
                            domainParameterScoreMap.put(domain, new DomainParameterInfoBean());
                        }

                        DomainParameterInfoBean bean = domainParameterScoreMap.get(domain);
                        bean.setDomain(domain);
                        bean.setParameterName(resultSet.getString("parameter_name"));
                        bean.setScore(resultSet.getInt("score"));
                        // bean.setCardinality(resultSet.getInt("cardinality"));
                        bean.setStatus(resultSet.getInt("status"));
                        bean.setPattern(resultSet.getString("pattern"));
                    }
                }
            }, EtilizeAnalyticsProperties.getInstance());

        } catch (DAOException e) {
            e.printStackTrace();
        }
        return domainParameterScoreMap;

    }

    public static List<DomainParameterInfoBean> getDomainParameterScoresByDomain(final String domain) {
        final List<DomainParameterInfoBean> domainParameterScoreList = new ArrayList<DomainParameterInfoBean>();

        try {
            String sql = "SELECT * FROM domain_parameter_score WHERE domain = ?";
            DAOUtils.executeSelect(sql, new ParameterMapping() {
                public void populatePreparedStatement(PreparedStatement stmt) throws SQLException {
                    stmt.setString(1, domain);

                }
            }, new ResultSetMapping() {

                public void processResultSet(ResultSet resultSet) throws SQLException {
                    while (resultSet.next()) {

                        DomainParameterInfoBean bean = new DomainParameterInfoBean();
                        bean.setDomain(domain);
                        bean.setParameterName(resultSet.getString("parameter_name"));
                        bean.setScore(resultSet.getInt("score"));
                        bean.setFullParamCardinality(resultSet.getInt("fullCardinality"));
                        bean.setTokenizeParamCardinality(resultSet.getInt("tokenizeCardinality"));
                        bean.setStatus(resultSet.getInt("status"));
                        bean.setPattern(resultSet.getString("pattern"));

                        domainParameterScoreList.add(bean);
                    }
                }
            }, EtilizeAnalyticsProperties.getInstance());

        } catch (DAOException e) {
            e.printStackTrace();
        }
        return domainParameterScoreList;

    }

    public static void insertDomainParameterScores(final DomainParameterInfoBean bean) {
        try {
            String sql = "INSERT INTO domain_parameter_score (" + "domain, parameter_name, " + "score, fullCardinality,"
                    + "tokenizeCardinality, status," + " pattern,parameterDocumentCount,"
                    + "domainDocumentCount,tokenizeRatio," + "fullRatio,tokenizeParamValues," + "fullParmValues) "
                    + "VALUES (? , ? ," + " ? , ? ," + " ? , ? ," + " ? , ? ," + " ? , ?," + " ?, ?, " + "? )";
            DAOUtils.executeInsert(sql, new ParameterMapping() {
                public void populatePreparedStatement(PreparedStatement stmt) throws SQLException {

                    stmt.setString(1, bean.getDomain());
                    stmt.setString(2, bean.getParameterName());
                    stmt.setInt(3, bean.getScore());
                    stmt.setInt(4, bean.getFullParamCardinality());
                    stmt.setInt(5, bean.getTokenizeParamCardinality());
                    stmt.setInt(6, bean.getStatus());
                    stmt.setString(7, bean.getPattern());
                    stmt.setLong(8, bean.getTotalDocument());
                    stmt.setLong(9, bean.getTotalDomainDocument());
                    stmt.setDouble(10, bean.getTokenizeParamRatio());
                    stmt.setDouble(11, bean.getFullParamRatio());
                    stmt.setString(12, bean.getTokenizeParamValues());
                    stmt.setString(13, bean.getFullParamValues());
                }
            }, EtilizeAnalyticsProperties.getInstance());

        } catch (DAOException e) {
            e.printStackTrace();
            log.error(e.getMessage() + " : " + bean);
        }
    }

    public static void insertDomainParameterValue(final String domain, final String key, final String value,
            final long docCount) {
        try {
            String sql = "INSERT INTO domain_parameter_value (domain, `key`, `value`,docCount) " + "VALUES (?, ?, ?,?)";
            DAOUtils.executeInsert(sql, new ParameterMapping() {
                public void populatePreparedStatement(PreparedStatement stmt) throws SQLException {
                    stmt.setString(1, domain);
                    stmt.setString(2, key);
                    stmt.setString(3, value);
                    stmt.setLong(4, docCount);
                }
            }, EtilizeAnalyticsProperties.getInstance());

        } catch (DAOException e) {
            e.printStackTrace();
            log.error(e.getMessage());
        }
    }

    public static HashMap<String, List<DomainParameterInfoBean>> getAllParameterName() {
        final HashMap<String, List<DomainParameterInfoBean>> urlKeys = new HashMap<String, List<DomainParameterInfoBean>>();
        String sql = "select * from domain_parameter_score where `status` = 1";
        try {
            DAOUtils.executeSelect(sql, null, new ResultSetMapping() {
                public void processResultSet(ResultSet resultSet) throws SQLException {
                    while (resultSet.next()) {
                        String webUrl = resultSet.getString("domain");

                        List<DomainParameterInfoBean> lst;
                        if (urlKeys.containsKey(webUrl)) {
                            lst = (List<DomainParameterInfoBean>) urlKeys.get(webUrl);
                        } else {
                            lst = new ArrayList<DomainParameterInfoBean>();
                        }
                        DomainParameterInfoBean bean = new DomainParameterInfoBean();
                        bean.setParameterName(resultSet.getString("parameter_name"));
                        bean.setPattern(resultSet.getString("pattern"));
                        lst.add(bean);
                        urlKeys.put(webUrl, lst);
                    }
                }
            }, EtilizeAnalyticsProperties.getInstance());
        } catch (DAOException e) {
            e.printStackTrace();
        }
        return urlKeys;
    }

}
