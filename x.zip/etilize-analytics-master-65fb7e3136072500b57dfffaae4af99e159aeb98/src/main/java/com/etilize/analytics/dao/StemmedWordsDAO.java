package com.etilize.analytics.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import com.etilize.analytics.EtilizeAnalyticsProperties;
import com.etilize.commons.dao.DAOException;
import com.etilize.commons.dao.DAOUtils;
import com.etilize.commons.dao.ResultSetMapping;

public class StemmedWordsDAO {

    public static Set<String> getAllKeywords() {
        final Set<String> keywords = new HashSet<String>();
        try {
            String sql = "select * from words WHERE keyword not  REGEXP '^[0-9]+$' and length(keyword)>2";
            DAOUtils.executeSelect(sql, null, new ResultSetMapping() {
                public void processResultSet(ResultSet resultSet) throws SQLException {
                    while (resultSet.next()) {
                        String word = resultSet.getString("keyword");
                        keywords.add(word.toLowerCase());
                    }
                }
            }, EtilizeAnalyticsProperties.getInstance());

        } catch (DAOException e) {
            e.printStackTrace();
        }
        return keywords;

    }
}
