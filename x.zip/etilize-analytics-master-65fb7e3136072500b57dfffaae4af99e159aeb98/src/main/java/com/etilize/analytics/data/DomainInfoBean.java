package com.etilize.analytics.data;

import java.util.List;

public class DomainInfoBean {

    private int id;
    private String domain;
    private List<DomainParameterInfoBean> domainParameterInfo;

    public DomainInfoBean(String domain) {
        super();
        this.domain = domain;
    }

    public DomainInfoBean(int id) {
        super();
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public List<DomainParameterInfoBean> getDomainParameterInfo() {
        return domainParameterInfo;
    }

    public void setDomainParameterInfo(List<DomainParameterInfoBean> domainParameterInfo) {
        this.domainParameterInfo = domainParameterInfo;
    }

}
