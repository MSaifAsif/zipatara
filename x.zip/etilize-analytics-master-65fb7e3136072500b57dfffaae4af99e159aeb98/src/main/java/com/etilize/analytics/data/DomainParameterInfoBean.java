package com.etilize.analytics.data;

import java.util.Collection;

public class DomainParameterInfoBean {

    private int domainId;
    private String domain;
    private String parameterName;
    private int score;
    private int tokenizeParamCardinality;
    private int fullParamCardinality;
    private int status;
    private String pattern;
    private long totalDocument;
    private long totalDomainDocument;
    private double fullParamRatio;
    private double tokenizeParamRatio;
    private String fullParamValues;
    private String tokenizeParamValues;
    private Collection<String> parameterValues;

    public int getFullParamCardinality() {
        return fullParamCardinality;
    }

    public void setFullParamCardinality(int fullParamCardinality) {
        this.fullParamCardinality = fullParamCardinality;
    }

    public DomainParameterInfoBean() {
    }

    public DomainParameterInfoBean(String parameterName) {
        this.parameterName = parameterName;
    }

    public int getDomainId() {
        return domainId;
    }

    public void setDomainId(int domainId) {
        this.domainId = domainId;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getParameterName() {
        return parameterName;
    }

    public void setParameterName(String parameterName) {
        this.parameterName = parameterName;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getPattern() {
        return pattern;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    public Collection<String> getParameterValues() {
        return parameterValues;
    }

    public void setParameterValues(Collection<String> parameterValues) {
        this.parameterValues = parameterValues;
    }

    @Override
    public String toString() {
        return "[domain=" + this.getDomain() + ", parameterName=" + this.getParameterName() + ", score="
                + this.getScore() + ", Full Param Cardinality=" + this.getFullParamCardinality()
                + ", Tokenize Param Cardinality=" + this.getTokenizeParamCardinality() + "]";
    }

    public long getTotalDocument() {
        return totalDocument;
    }

    public void setTotalDocument(long totalDocument) {
        this.totalDocument = totalDocument;
    }

    public long getTotalDomainDocument() {
        return totalDomainDocument;
    }

    public void setTotalDomainDocument(long totalDomainDocument) {
        this.totalDomainDocument = totalDomainDocument;
    }

    public int getTokenizeParamCardinality() {
        return tokenizeParamCardinality;
    }

    public void setTokenizeParamCardinality(int tokenizeParamCardinality) {
        this.tokenizeParamCardinality = tokenizeParamCardinality;
    }

    public double getTokenizeParamRatio() {
        return tokenizeParamRatio;
    }

    public void setTokenizeParamRatio(double tokenizeParamRatio) {
        this.tokenizeParamRatio = tokenizeParamRatio;
    }

    public double getFullParamRatio() {
        return fullParamRatio;
    }

    public void setFullParamRatio(double fullParamRatio) {
        this.fullParamRatio = fullParamRatio;
    }

    public String getTokenizeParamValues() {
        return tokenizeParamValues;
    }

    public void setTokenizeParamValues(String tokenizeParamValues) {
        this.tokenizeParamValues = tokenizeParamValues;
    }

    public String getFullParamValues() {
        return fullParamValues;
    }

    public void setFullParamValues(String fullParamValues) {
        this.fullParamValues = fullParamValues;
    }
}
