package com.etilize.analytics.data;

import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.io.ArrayWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.elasticsearch.hadoop.mr.LinkedMapWritable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// TODO wrap LinkedMapWritable in HahsMap or soemthing and expose that as jsonDoc for updating
public class ESDocument {

    private String documentId;
    private LinkedMapWritable jsonDoc;

    private static Logger logger = LoggerFactory.getLogger(ESDocument.class);

    public ESDocument(String documentId, LinkedMapWritable jsonDoc) {

        this.documentId = documentId;
        this.jsonDoc = jsonDoc;
    }

    public String getDocumentId() {
        return documentId;
    }

    public LinkedMapWritable getJsonDoc() {
        return jsonDoc;
    }

    /**
     * <p>
     * This function is used to add new field in the ElasticSearch document. All
     * values in String List will be concatenated to single string and it will
     * be added to ElasticSearch document with the given field name
     * </p>
     * 
     * @param fieldName
     *            This parameter will be insert/update in the Elasticsearch
     *            document If fieldName exist in the document then old field
     *            will be updated else it will add new field.
     * 
     * @param values
     *            String list containing values
     * 
     */
    public void addField(String fieldName, String[] values) {
        if (values.length > 0) {
            jsonDoc.put(new Text(fieldName), new ArrayWritable(values));
        }
    }

    public void addField(String fieldName, int[] values) {
        if (values.length > 0) {
            ArrayWritable intArrayWritable = new ArrayWritable(IntWritable.class);
            IntWritable intergers[] = new IntWritable[values.length];
            for (int i = 0; i < values.length; i++) {
                logger.info("Add Field : " + values[i]);
                intergers[i] = new IntWritable(values[i]);
            }
            intArrayWritable.set(intergers);
            jsonDoc.put(new Text(fieldName), intArrayWritable);
        }
    }

    public void addField(String fieldName, String value) {
        jsonDoc.put(new Text(fieldName), new Text(value));
    }

    public void addField(String fieldName, int value) {
        jsonDoc.put(new Text(fieldName), new IntWritable(value));
    }

    /**
     * <p>
     * This function is used to add new fields in the ElasticSearch document.
     * All entries in hash map will be added to ElasticSearch document.
     * </p>
     * 
     * @param values
     *            Hash map containing key value pairs that will be added in the
     *            document
     */
    public void addFields(HashMap<String, Writable> values) {
        for (Map.Entry<String, Writable> entry : values.entrySet()) {
            if (entry.getValue() instanceof Text) {
                addField(entry.getKey(), entry.getValue().toString());
            } else if (entry.getValue() instanceof IntWritable) {
                addField(entry.getKey(), Integer.parseInt(entry.getValue().toString()));
            }
        }
    }

    public void removeField(String fieldName) {
        try {
            jsonDoc.remove(new Text(fieldName));
        } catch (Exception ex) {
            logger.error(ex.getMessage());
        }
    }

    public void renameField(String oldName, String newName) {

        Writable value = (Text) jsonDoc.get(new Text(oldName));
        removeField(oldName);
        jsonDoc.put(new Text(newName), value);
    }
}
