package com.etilize.analytics.data;

import java.util.List;
import java.util.Map;

public class ESSearchRequest {

    private Map<String, String> filters;
    private String index;
    private List<String> aggParams;
    private int size;
    private List<String> fields;
    private long timeOut;
    private String scrollId;

    public ESSearchRequest() {
        super();
    }

    public ESSearchRequest(String index) {
        this();
        this.index = index;
    }

    public ESSearchRequest(String index, List<String> aggParams) {
        this(index);
        this.aggParams = aggParams;
    }

    public ESSearchRequest(String index, Map<String, String> filters, List<String> aggParams, Integer size) {
        this(index, aggParams);
        this.filters = filters;
        this.size = size;
    }

    public Map<String, String> getFilters() {
        return filters;
    }

    public void setFilters(Map<String, String> filters) {
        this.filters = filters;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public List<String> getAggParams() {
        return aggParams;
    }

    public void setAggParams(List<String> aggParams) {
        this.aggParams = aggParams;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public List<String> getFields() {
        return fields;
    }

    public void setFields(List<String> fields) {
        this.fields = fields;
    }

    public long getTimeOut() {
        return timeOut;
    }

    public void setTimeOut(long timeOut) {
        this.timeOut = timeOut;
    }

    public String getScrollId() {
        return scrollId;
    }

    public void setScrollId(String scrollId) {
        this.scrollId = scrollId;
    }
}
