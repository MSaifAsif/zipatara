package com.etilize.analytics.data;

import java.util.Map;

public class ESSearchResponse {

    private Map<String, Long> aggregatedData;

    private Map<String, DocumentData> documentData;

    private String scrollId;

    public ESSearchResponse() {

    }

    public ESSearchResponse(String scrollId) {
        super();
        this.scrollId = scrollId;
    }

    public Map<String, Long> getAggregatedData() {
        return aggregatedData;
    }

    public void setAggregatedData(Map<String, Long> aggregatedData) {
        this.aggregatedData = aggregatedData;
    }

    public Map<String, DocumentData> getDocumentData() {
        return documentData;
    }

    public void setDocumentData(Map<String, DocumentData> documentData) {
        this.documentData = documentData;
    }

    public String getScrollId() {
        return scrollId;
    }

    public void setScrollId(String scrollId) {
        this.scrollId = scrollId;
    }

}
