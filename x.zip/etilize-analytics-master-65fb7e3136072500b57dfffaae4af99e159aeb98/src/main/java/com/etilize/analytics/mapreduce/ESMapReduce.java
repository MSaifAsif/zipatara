package com.etilize.analytics.mapreduce;

import java.io.IOException;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.util.Tool;
import org.elasticsearch.hadoop.mr.EsInputFormat;
import org.elasticsearch.hadoop.mr.EsOutputFormat;
import org.elasticsearch.hadoop.mr.LinkedMapWritable;

import com.etilize.analytics.EtilizeAnalyticsProperties;
import com.etilize.analytics.data.ESDocument;
import com.etilize.analytics.task.DocumentUpdateTask;
import com.etilize.elasticsearch.ESSettings;

import lombok.extern.log4j.Log4j;

/**
 * <p>
 * This class contains Hadoop MapReduce framework with ElasticSearch. This class
 * is used to run hadoop mapper job. Configurations of hadoop and mapreduce must
 * be defined at EtilizeAnalytics.properties
 * </p>
 * 
 * @version 0.1.0
 */

@Log4j
public class ESMapReduce extends Configured implements Tool {

    @SuppressWarnings("rawtypes")
    private static class ElasticSearchInputMapper extends Mapper {

        /**
         * <p>
         * This function maps Elastic Search document to each hadoop node and
         * update the document with new changes.
         * </p>
         * 
         */
        @SuppressWarnings("unchecked")
        @Override
        protected void map(Object key, Object value, Context context) throws IOException, InterruptedException {

            Text docId = (Text) key;

            // log.info("Document Id : " + docId.toString());

            LinkedMapWritable doc = ((LinkedMapWritable) value);

            ESDocument esDocument = new ESDocument(docId.toString(), doc);
            //
            // log.info("Document Before Update : "
            // + esDocument.getJsonDoc().toString());
            esDocument = DocumentUpdateTask.INSTANCE.run(esDocument);
            // log.info("Document After Update : "
            // + esDocument.getJsonDoc().toString());
            context.write(NullWritable.get(), esDocument.getJsonDoc());
        }
    }

    /**
     * <p>
     * This function is used run Hadoop MapReduce Task. This function will not
     * output any result or file at the end of process.
     * </p>
     */

    public int run(String[] args) throws Exception {

        try {
            EtilizeAnalyticsProperties prop = EtilizeAnalyticsProperties.getInstance();

            log.info("Starting ES-Hadoop");

            @SuppressWarnings("deprecation")
            Job job = new Job(ESSettings.INSTANCE.getElasticSearchConfiguration());
            String jobName = prop.getPropertyValue("job.name");
            job.setJobName(jobName);
            job.setMapperClass(ElasticSearchInputMapper.class);
            job.setJarByClass(ElasticSearchInputMapper.class);
            job.setInputFormatClass(EsInputFormat.class);
            job.setOutputFormatClass(EsOutputFormat.class);
            job.setMapOutputValueClass(LinkedMapWritable.class);
            String noOfReduceTasks = prop.getPropertyValue("job.reduce.tasks");
            if (!("".equals(noOfReduceTasks)))
                job.setNumReduceTasks(Integer.parseInt(noOfReduceTasks));

            int returnValue = job.waitForCompletion(true) ? 0 : 1;
            System.out.println("job.isSuccessful " + job.isSuccessful());
            return returnValue;
            // return 0;
        } catch (Exception ex) {
            log.error(ex.getMessage());
            log.error(ex.getCause());
            log.error(ex.getLocalizedMessage());
            return 0;
        }

    }
}