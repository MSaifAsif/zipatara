package com.etilize.analytics.operations;

import com.etilize.analytics.data.ESDocument;

import lombok.extern.log4j.Log4j;

@Log4j
public class AddDocumentId implements iOperation {

    final static String FIELD_DOCUMENT_ID = "doc_id";

    public ESDocument perform(ESDocument esDocument) {

        esDocument.addField(FIELD_DOCUMENT_ID, esDocument.getDocumentId());
        log.debug(esDocument.getJsonDoc().toString());
        return esDocument;
    }
}
