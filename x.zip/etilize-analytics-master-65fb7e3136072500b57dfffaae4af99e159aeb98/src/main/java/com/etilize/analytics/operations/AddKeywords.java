package com.etilize.analytics.operations;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;

import org.apache.hadoop.io.Text;

import com.esotericsoftware.minlog.Log;
import com.etilize.analytics.data.ESDocument;
import com.etilize.analytics.parser.UrlParser;

import lombok.extern.log4j.Log4j;

@Log4j
public class AddKeywords implements iOperation {

    public ESDocument perform(ESDocument esDocument) {
        final String FIELD_WEB_URL = "web_url";
        final String FIELD_REQUEST_PARAMETERS = "request_parameters";

        Log.debug("getting web url");
        if (esDocument.getJsonDoc().containsKey(new Text(FIELD_WEB_URL))) {
            if (esDocument.getJsonDoc().containsKey(new Text("search_keyword"))) {
                esDocument.removeField("search_keyword");
            }
            String webUrl = esDocument.getJsonDoc().get(new Text(FIELD_WEB_URL)).toString();
            Log.debug("getting request parameters");
            if (esDocument.getJsonDoc().containsKey(new Text(FIELD_REQUEST_PARAMETERS))) {
                String requestParameter = esDocument.getJsonDoc().get(new Text(FIELD_REQUEST_PARAMETERS)).toString();
                try {
                    Log.debug("Web URL : " + webUrl + " Request Paramter : " + requestParameter);
                    HashMap<String, String> parsedValues = UrlParser.INTSANCE.extractValues(webUrl, requestParameter);
                    esDocument.addField("search_keyword",
                            parsedValues.values().toArray(new String[parsedValues.values().size()]));

                } catch (UnsupportedEncodingException usE) {
                    log.error("Error when extracting values from web url", usE);
                }
            }
        }
        return esDocument;
    }
}
