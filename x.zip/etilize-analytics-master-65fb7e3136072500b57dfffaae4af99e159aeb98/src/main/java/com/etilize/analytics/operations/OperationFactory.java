package com.etilize.analytics.operations;

import static org.junit.Assert.assertEquals;

import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import org.junit.Test;

import com.etilize.analytics.EtilizeAnalyticsProperties;
import com.etilize.commons.TextUtils;

public enum OperationFactory {
    INSTANCE;
    private Logger logger = Logger.getLogger(OperationFactory.class);
    private volatile Map<String, Object> operationInstances = new HashMap<String, Object>();

    private OperationFactory() {
        logger = Logger.getLogger(OperationFactory.class);
        getOperationInstance(iOperation.class);
    }

    public Map<String, Object> getOperationInstances() {
        return operationInstances;
    }

    public void setOperationInstances(Map<String, Object> operationInstances) {
        this.operationInstances = operationInstances;
    }

    @SuppressWarnings("unchecked")
    private <T> T getOperationInstance(Class<T> opertaionInterface) {
        Object pluginInstance = operationInstances.get(opertaionInterface.getName());

        if (pluginInstance == null) {
            synchronized (opertaionInterface) {
                pluginInstance = operationInstances.get(opertaionInterface.getName());
                if (pluginInstance != null) {
                    logger.info("OperationFactory => Lost the race to create " + opertaionInterface.getSimpleName());
                    return (T) pluginInstance;
                }

                String implClasses = EtilizeAnalyticsProperties.getProperty("update.operations");
                System.out.println("Impl Classes " + implClasses);
                if (TextUtils.isNotEmpty(implClasses)) {
                    // Someone has defined a custom implementation of T (we
                    // won't instantiate the default impl)
                    StringTokenizer toker = new StringTokenizer(implClasses, ",");

                    // We need to instantiate these plugins in reverse order so
                    // we will use a stack to help us
                    Queue<String> queue = new LinkedList<String>();
                    while (toker.hasMoreTokens()) {
                        queue.add(toker.nextToken());
                    }

                    // At this point pluginInstance is null
                    while (!queue.isEmpty()) {
                        String implClass = queue.poll();
                        // Note that we pass the previous pluginInstance to this
                        // new instance
                        pluginInstance = createPlugin(implClass, opertaionInterface);
                        operationInstances.put(pluginInstance.toString(), pluginInstance);
                    }

                }

            }
        }

        return (T) pluginInstance;
    }

    @SuppressWarnings("unchecked")
    private <T> T createPlugin(String implementationClassName, Class<T> pluginInterface) {
        String fullyQualifiedInterfaceName = pluginInterface.getName();
        System.out.println("OperationFactory => Creating an instance of " + fullyQualifiedInterfaceName
                + " as implemented by " + implementationClassName);
        T result = null;

        try {
            // We will look at the implementation's constructors.
            // We are interested in ctors with no args and with one arg (the arg
            // being an instance of T).
            Class<?> implClass = Class.forName(implementationClassName);
            Constructor<?>[] allConstructors = implClass.getDeclaredConstructors();

            Constructor<?> nullaryCtor = null;
            if (allConstructors.length > 0) {
                for (Constructor<?> ctor : allConstructors) {
                    logger.debug(ctor + " is a ctor of " + fullyQualifiedInterfaceName);
                    Class<?>[] pType = ctor.getParameterTypes();
                    if (pType.length == 0) {
                        nullaryCtor = ctor;
                    }
                }
            }
            if (nullaryCtor != null) {
                result = (T) nullaryCtor.newInstance();
            } else {
                throw new RuntimeException("No ctor in " + implementationClassName);
            }
        } catch (Exception e) {
            logger.fatal("OperationFactory => Failed to create a " + implementationClassName, e);
            throw new RuntimeException("OperationFactory => Failed to create a " + implementationClassName, e);
        }
        logger.info("OperationFactory => successfully created an instance of " + implementationClassName);
        return result;
    }

    public static class UnitTest {

        @Test
        public void testDefault() throws Exception {
            assertEquals(OperationFactory.INSTANCE.getOperationInstances().size(), 2);
        }
    }

}
