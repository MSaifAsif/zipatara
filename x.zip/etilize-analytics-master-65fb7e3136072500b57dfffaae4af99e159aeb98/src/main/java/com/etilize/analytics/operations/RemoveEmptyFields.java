package com.etilize.analytics.operations;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import org.apache.hadoop.io.Writable;

import com.etilize.analytics.data.ESDocument;

/**
 * <p>
 * Removes all empty fields from the Elasticsearch document.
 * </p>
 */
// tested by taislam
public class RemoveEmptyFields implements iOperation {
    public RemoveEmptyFields() {
    }

    public ESDocument perform(ESDocument esDocument) {

        List<String> removeFields = new ArrayList<String>();
        for (Entry<Writable, Writable> entry : esDocument.getJsonDoc().entrySet()) {

            if (entry.getValue().toString().equals("(null)")) {
                removeFields.add(entry.getKey().toString());
            }
        }
        for (String field : removeFields) {
            esDocument.removeField(field);
        }
        return esDocument;
    }
}
