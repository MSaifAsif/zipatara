package com.etilize.analytics.operations;

import org.apache.hadoop.io.Text;

import com.etilize.analytics.EtilizeAnalyticsProperties;
import com.etilize.analytics.data.ESDocument;

/**
 * <p>
 * Removes all empty fields from the Elasticsearch document.
 * </p>
 */
// tested by taislam
public class RemoveFields implements iOperation {

    public RemoveFields() {
    }

    public ESDocument perform(ESDocument esDocument) {
        String fieldNames = (EtilizeAnalyticsProperties.getInstance()
                .getPropertyValue("operation.removeFields.fieldNames"));
        if (fieldNames != null) {
            String[] fields = fieldNames.split(",");
            for (String field : fields) {
                if (esDocument.getJsonDoc().containsKey(new Text(field.trim()))) {
                    esDocument.removeField(field.trim());
                }
            }
        }
        return esDocument;
    }
}
