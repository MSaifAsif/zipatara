package com.etilize.analytics.operations;

import com.etilize.analytics.EtilizeAnalyticsProperties;
import com.etilize.analytics.data.ESDocument;

//tested by taislam
public class RenameFields implements iOperation {
    public ESDocument perform(ESDocument esDocument) {
        try {
            String fieldNames = (EtilizeAnalyticsProperties.getInstance()
                    .getPropertyValue("operation.renameFields.fieldNames"));
            String[] allFields = fieldNames.split(" ");
            for (String fields : allFields) {
                String[] oldNewFields = fields.split(",");
                esDocument.renameField(oldNewFields[0], oldNewFields[1]);
            }
        } catch (Exception ex) {
            System.out.println("Rename Field Exception : " + ex.getMessage());
        }
        return esDocument;
    }

}
