package com.etilize.analytics.operations;

import java.util.Map.Entry;

import org.apache.hadoop.io.Writable;

import com.etilize.analytics.EtilizeAnalyticsProperties;
import com.etilize.analytics.data.ESDocument;

/**
 * <p>
 * This class is used to replace given regex pattern to new value in
 * Elasticsearch Document
 * </p>
 * 
 * @param regexPattern
 *            pattern that will match in field value
 * @param replaceValue
 *            String that will be replace if given regex pattern matched.
 */
// tested by taislam
public class ReplaceValue implements iOperation {
    public ESDocument perform(ESDocument esDocument) {
        String pattern = EtilizeAnalyticsProperties.getInstance().getPropertyValue("update.value.pattern");
        String replacement = EtilizeAnalyticsProperties.getInstance().getPropertyValue("update.value.replacement");
        if (pattern != null && replacement != null) {
            String value;
            for (Entry<Writable, Writable> entry : esDocument.getJsonDoc().entrySet()) {
                // key = entry.getKey().toString();
                value = entry.getValue().toString();
                value = value.replaceAll(pattern, replacement);
                esDocument.addField(entry.getKey().toString(), value);
            }
        } else {

        }

        return esDocument;
    }

}
