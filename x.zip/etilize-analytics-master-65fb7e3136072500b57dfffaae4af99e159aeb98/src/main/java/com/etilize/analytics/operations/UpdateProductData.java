package com.etilize.analytics.operations;

import java.util.HashMap;
import java.util.Map.Entry;

import org.apache.hadoop.io.Text;
import org.codehaus.jackson.map.ObjectMapper;

import com.etilize.analytics.data.ESDocument;
import com.etilize.redis.RedisFactory;
import com.etilize.redis.RedisSettings;

import lombok.extern.log4j.Log4j;

@Log4j
public class UpdateProductData implements iOperation {
    public ESDocument perform(ESDocument esDocument) {
        try {
            String productFields = RedisSettings.INSTANCE.getProductDataField();
            String[] fields = productFields.split(" ");
            for (String str : fields) {
                esDocument.removeField(str);
            }

            String productId = esDocument.getJsonDoc().get(new Text("product_id")).toString();
            log.info("Json Product Id : " + productId);
            String productData = RedisFactory.INSTANCE.getClient(RedisSettings.INSTANCE.getProductDataServer(),
                    RedisSettings.INSTANCE.getProductDataPort()).get(productId);

            productData = productData.replace(" \\", " \\\\");
            productData = productData.replace("\" ", "\\\" ");

            log.info("Product Id : " + productId);
            log.info("Product Data : " + productData);
            if (productData != null) {
                @SuppressWarnings("unchecked")
                HashMap<String, String> result = new ObjectMapper().readValue(productData, HashMap.class);
                for (Entry<String, String> entry : result.entrySet()) {
                    esDocument.addField(entry.getKey(), entry.getValue());
                }
            }
        } catch (Exception ex) {
            log.error(ex.getMessage());
        }

        return esDocument;
    }
}
