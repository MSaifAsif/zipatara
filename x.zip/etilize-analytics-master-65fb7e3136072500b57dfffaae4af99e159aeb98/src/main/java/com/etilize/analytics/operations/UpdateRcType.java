package com.etilize.analytics.operations;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.io.Text;

import com.etilize.analytics.data.ESDocument;

//tested by taislam
public class UpdateRcType implements iOperation {
    private static HashMap<String, String> rcTypeReWrite = new HashMap<String, String>();
    private static HashMap<Pattern, Pattern> rcTypePatterns = new HashMap<Pattern, Pattern>();
    static {
        rcTypeReWrite.put("thumbnail", "160");
        rcTypeReWrite.put("large", "300");
        rcTypeReWrite.put("Thumbnail", "160");
        rcTypeReWrite.put("Large", "300");
        rcTypeReWrite.put("images", "Main");

        rcTypePatterns.put(Pattern.compile("/.*content\\.etilize\\.com\\/[a-zA-Z].*/[a-zA-Z].*/[0-9]{8,10}"),
                Pattern.compile("(?<=content\\.etilize\\.com\\/).*.(?=/.*./)"));
        rcTypePatterns.put(Pattern.compile("/.*content\\.etilize\\.com\\/Logo\\/[a-zA-Z].*/"),
                Pattern.compile("(?<=content\\.etilize\\.com/)[a-zA-Z/]+(?=\\/)"));
        rcTypePatterns.put(Pattern.compile("/.*content\\.etilize\\.com\\/images\\/[a-zA-Z].*/"),
                Pattern.compile("(?<=content\\.etilize\\.com/images/)[a-zA-Z/]+(?=\\/)"));

        rcTypePatterns.put(Pattern.compile(".*."),
                Pattern.compile("(?<=content\\.etilize\\.com/)[a-zA-Z0-9-]+(?=\\/)"));

    };

    public ESDocument perform(ESDocument esDocument) {
        if (esDocument.getJsonDoc().containsKey("rc_url")) {
            String rc_url = esDocument.getJsonDoc().get(new Text("rc_url")).toString();
            String rc_type = "";
            if (rc_url != null) {
                for (Entry<Pattern, Pattern> pattern : rcTypePatterns.entrySet()) {
                    Matcher matcher = pattern.getKey().matcher(rc_url);

                    if (matcher.find()) {
                        matcher = pattern.getValue().matcher(rc_url);
                        if (matcher.find()) {
                            rc_type = matcher.group();
                            if (rcTypeReWrite.containsKey(rc_type)) {
                                rc_type = rcTypeReWrite.get(rc_type);
                            }
                            break;
                        }
                    }
                }
            }
            if (rc_type.trim().length() > 0) {
                esDocument.addField("rc_type_hadoop", rc_type);
            }
        }
        return esDocument;
    }
}
