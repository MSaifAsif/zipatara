package com.etilize.analytics.operations;

import com.etilize.analytics.data.ESDocument;

public interface iOperation {

    public ESDocument perform(ESDocument esDocument);
}
