package com.etilize.analytics.parser;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.esotericsoftware.minlog.Log;
import com.etilize.analytics.EtilizeAnalyticsProperties;
import com.etilize.analytics.dao.DomainParameterInfoDAO;
import com.etilize.analytics.data.DomainParameterInfoBean;

/**
 * <p>
 * This class is used to extract parameter value(s) from a given URL identified
 * key of domains. For parameter identification process, please look into @{link
 * ParameterIdentifier}
 * </p>
 * <br/>
 * <p>
 * This class fetches urlKeys from database in a HashMap ({@code urlKeys})
 * </p>
 * <ul>
 * <li>Key: Domain name</li>
 * <li>Value: Request parameter key that needs to be extracted</li>
 * </ul>
 *
 * @version 0.1.0
 */
public enum UrlParser {
    INTSANCE;

    private EtilizeAnalyticsProperties prop;
    private HashMap<String, List<DomainParameterInfoBean>> urlKeys;
    private String urlValueRegex, fieldValueRegex;

    private UrlParser() {
        prop = EtilizeAnalyticsProperties.getInstance();
        urlValueRegex = prop.getPropertyValue("parser.urlValueRegex");
        fieldValueRegex = prop.getPropertyValue("parser.fieldValueRegex");
        urlKeys = DomainParameterInfoDAO.getAllParameterName();
    }

    /**
     * This function matches the field name in the json string and returns field
     * value as string
     *
     * @param fieldName
     *            Json field Name
     * @param jsonString
     *            Any json document provided in string format
     *
     * @return String containing the fieldName value
     */

    public String getValue(String fieldName, String jsonString) {
        Pattern p = Pattern.compile(fieldValueRegex.replace("{FieldName}", fieldName));
        Matcher m = p.matcher(jsonString);
        if (m.find()) {
            return m.group(0);
        } else

        {
            return "";
        }
    }

    /**
     * This function is used to fetch value of domain keys provided in keyUrLs
     *
     * @param webUrl
     *            domain name
     * @param requestParameters
     *            complete URL with domain name, consists of request parameters
     *            key value pair
     *
     * @return HashMap<String,String> containing the webUrl identified key as
     *         Hashmap Key and extracted value fetch against that key as Hashmap
     *         value
     */

    public HashMap<String, String> extractValues(String webUrl, String requestParameters)
            throws UnsupportedEncodingException {
        String parameterValue = "";
        Pattern p;
        Matcher m;
        HashMap<String, String> keywords = new HashMap<String, String>();
        if (urlKeys.containsKey(webUrl)) {
            List<DomainParameterInfoBean> value = (List<DomainParameterInfoBean>) urlKeys.get(webUrl);
            Log.info("Web URL : " + webUrl + " found having " + value.size() + " keys ");
            if (requestParameters.length() > 0 && requestParameters != "/") {
                if (urlKeys.containsKey(webUrl)) {
                    for (DomainParameterInfoBean parameter : value) {
                        if (parameter.getPattern() == null) {
                            p = Pattern.compile(urlValueRegex.replace("{key}", parameter.getParameterName()));
                        } else {
                            p = Pattern.compile(parameter.getPattern());
                        }
                        m = p.matcher(requestParameters);
                        if (m.find()) {
                            parameterValue = m.group(0);
                            parameterValue = com.etilize.inquire.data.util.Utils.decode(parameterValue);

                            Log.info(" Key : " + parameter.getParameterName() + " Value : " + parameterValue);
                            keywords.put(parameter.getParameterName(), parameterValue);
                        }
                    }
                }
            }
        }
        return keywords;
    }

}