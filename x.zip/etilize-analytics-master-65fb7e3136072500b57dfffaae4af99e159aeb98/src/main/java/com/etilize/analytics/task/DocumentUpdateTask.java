package com.etilize.analytics.task;

import java.util.Map.Entry;

import com.etilize.analytics.data.ESDocument;
import com.etilize.analytics.operations.OperationFactory;
import com.etilize.analytics.operations.iOperation;

public enum DocumentUpdateTask implements iTask<ESDocument> {
    INSTANCE;
    public ESDocument run(ESDocument esDocument) {
        for (Entry<String, Object> operation : OperationFactory.INSTANCE.getOperationInstances().entrySet()) {
            iOperation tmp = iOperation.class.cast(operation.getValue());
            esDocument = tmp.perform(esDocument);
        }
        return esDocument;
    }
}
