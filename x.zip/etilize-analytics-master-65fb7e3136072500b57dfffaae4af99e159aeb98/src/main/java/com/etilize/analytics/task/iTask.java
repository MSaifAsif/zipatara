package com.etilize.analytics.task;

public interface iTask<T> {

    public T run(T obj);
}
