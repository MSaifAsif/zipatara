package com.etilize.elasticsearch;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequestBuilder;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.etilize.analytics.data.DocumentData;
import com.etilize.analytics.data.ESSearchRequest;
import com.etilize.analytics.data.ESSearchResponse;

public class ESReader {
    private static final Logger LOG = LoggerFactory.getLogger(ESReader.class);

    public static ESSearchResponse getAggregationResponse(ESSearchRequest request) {
        SearchRequestBuilder searchRequestBuilder = ESSettings.INSTANCE.getESTransportClient().prepareSearch()
                .setIndices(request.getIndex()).setSearchType(SearchType.COUNT);

        QueryBuilder query = QueryBuilders.matchAllQuery();

        searchRequestBuilder.setQuery(query);

        for (String aggField : request.getAggParams()) {
            TermsBuilder aggregationQuery = AggregationBuilders.terms(aggField).field(aggField).size(request.getSize());
            searchRequestBuilder.addAggregation(aggregationQuery);
        }

        Map<String, Long> aggregatedData = new LinkedHashMap<String, Long>();

        SearchResponse searchResponse = searchRequestBuilder.execute().actionGet();

        Aggregations aggregations = searchResponse.getAggregations();
        for (String aggregationName : aggregations.asMap().keySet()) {
            Terms aggregation = aggregations.get(aggregationName);
            Collection<Terms.Bucket> buckets = aggregation.getBuckets();

            for (Terms.Bucket bucket : buckets) {
                aggregatedData.put(bucket.getKey(), bucket.getDocCount());
            }

        }

        ESSearchResponse response = new ESSearchResponse();
        response.setAggregatedData(aggregatedData);

        return response;
    }

    /**
     * 
     * @param request
     */
    public static ESSearchResponse getScanResponse(ESSearchRequest request) {
        QueryBuilder query = QueryBuilders.matchAllQuery();
        FilterBuilder filteredBuilder = createFilter(request.getFilters());
        QueryBuilder queryBuilder = QueryBuilders.filteredQuery(query, filteredBuilder);

        SearchRequestBuilder scanRequestBuilder = ESSettings.INSTANCE.getESTransportClient().prepareSearch()
                .setIndices(request.getIndex()).setSearchType(SearchType.SCAN)
                .setScroll(new TimeValue(request.getTimeOut()));

        scanRequestBuilder.setQuery(queryBuilder).setSize(request.getSize());
        if (request.getFields() != null)
            scanRequestBuilder.addFields(request.getFields().toArray(new String[request.getFields().size()]));

        SearchResponse scanResponse = scanRequestBuilder.execute().actionGet();
        ESSearchResponse response = new ESSearchResponse(scanResponse.getScrollId());

        return response;
    }

    public static long getDocumentCount(ESSearchRequest request, String domain, String param) {
        MatchQueryBuilder domainMatch = QueryBuilders.matchQuery("web_url", domain);
        MatchQueryBuilder requestParameterMatch = QueryBuilders.matchQuery("request_parameters", param);

        QueryBuilder query = QueryBuilders.boolQuery().must(domainMatch).must(requestParameterMatch);

        SearchRequestBuilder scanRequestBuilder = ESSettings.INSTANCE.getESTransportClient().prepareSearch()
                .setIndices(request.getIndex()).setSearchType(SearchType.SCAN)
                .setScroll(new TimeValue(request.getTimeOut()));
        scanRequestBuilder.setQuery(query).setSize(request.getSize());
        SearchResponse scanResponse = scanRequestBuilder.execute().actionGet();
        long totalHits = scanResponse.getHits().getTotalHits();
        return totalHits;

    }

    public static long getDocumentCount(ESSearchRequest request, String domain, String param, String paramValue) {
        Set<String> documentIds = new HashSet<String>();
        MatchQueryBuilder domainMatch = QueryBuilders.matchQuery("web_url", domain);
        MatchQueryBuilder requestParameterMatch = QueryBuilders.matchQuery("request_parameters", param);
        MatchQueryBuilder requestParameterValueMatch = QueryBuilders.matchQuery("request_parameters", paramValue);
        QueryBuilder query = QueryBuilders.boolQuery().must(domainMatch).must(requestParameterMatch)
                .must(requestParameterValueMatch);

        SearchRequestBuilder scanRequestBuilder = ESSettings.INSTANCE.getESTransportClient().prepareSearch()
                .setIndices(request.getIndex()).setSearchType(SearchType.SCAN)
                .setScroll(new TimeValue(request.getTimeOut()));
        scanRequestBuilder.setQuery(query).setSize(request.getSize());
        SearchResponse scanResponse = scanRequestBuilder.execute().actionGet();
        for (SearchHit hit : scanResponse.getHits().getHits()) {

        }
        long totalHits = scanResponse.getHits().getTotalHits();
        return totalHits;

    }

    /**
     * 
     * @param request
     */
    public static ESSearchResponse getScrollResponse(ESSearchRequest request) {

        Map<String, DocumentData> documentData = new HashMap<String, DocumentData>();
        Date date1 = new Date();
        while (true) {

            SearchScrollRequestBuilder scrollRequestBuilder = ESSettings.INSTANCE.getESTransportClient()
                    .prepareSearchScroll(request.getScrollId());

            SearchResponse scrollResponse = scrollRequestBuilder.setScroll(new TimeValue(request.getTimeOut())).get();

            if (scrollResponse.getHits().hits().length == 0) {
                break;
            }

            for (SearchHit hit : scrollResponse.getHits().getHits()) {
                Map<String, String> fields = new HashMap<String, String>();
                // TODO fix the code to generalize similar code in loops
                if (hit.getFields() != null && hit.getFields().size() > 0) {
                    for (String fieldName : hit.getFields().keySet()) {
                        DocumentData doc = new DocumentData();
                        fields.put(fieldName, hit.getFields().get(fieldName).getValue().toString());

                        doc.setFields(fields);
                        documentData.put(hit.getId(), doc);
                    }
                } else if (hit.getSource() != null) {
                    for (String fieldName : hit.getSource().keySet()) {
                        DocumentData doc = new DocumentData();
                        fields.put(fieldName, hit.getSource().get(fieldName).toString());
                        doc.setFields(fields);
                        documentData.put(hit.getId(), doc);
                    }
                }
            }
        }
        ESSearchResponse response = new ESSearchResponse();
        response.setDocumentData(documentData);
        Date date2 = new Date();
        LOG.info("Scroll Response Time : " + String.valueOf(((date2.getTime() - date1.getTime()) / 1000)));
        return response;
    }

    /**
     * Create ElasticSearch FilterBuilder object from given filter values
     * 
     * @param filters
     * @return FilterBuilder
     */
    private static FilterBuilder createFilter(Map<String, String> filters) {
        if (filters.isEmpty()) {
            return null;
        } else {
            BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
            for (String filterField : filters.keySet()) {
                FilterBuilder fb = FilterBuilders.termFilter(filterField, filters.get(filterField));
                boolFilterBuilder.must(fb);
            }
            return boolFilterBuilder;
        }
    }

}
