package com.etilize.elasticsearch;

import java.util.Map.Entry;

import org.apache.hadoop.conf.Configuration;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.etilize.analytics.EtilizeAnalyticsProperties;

/**
 * <p>
 * This class contains ElasticSearch client and other settings related to
 * elasticsearch cluster and index
 * </p>
 * <br/>
 * <p>
 * ElasticSearch client configurations should be given at
 * EtilizeAnalytics.properties
 * </p>
 */

public enum ESSettings {
    INSTANCE;

    private EtilizeAnalyticsProperties prop;
    private String clusterName, serverUrl, readType, writeType, readIndex, writeIndex, fetchQuery;
    private int transportPort, httpPort;
    private Settings settings;
    private Client esTransportClient;
    private Configuration configuration;
    private Logger logger = LoggerFactory.getLogger(ESSettings.class);
    private String esConfigurationPrefix = "esconfiguration";

    @SuppressWarnings("resource")
    private ESSettings() {
        logger.info("In ES SEttings");
        prop = EtilizeAnalyticsProperties.getInstance();
        readType = prop.getPropertyValue("elasticsearch.read.type");
        writeType = prop.getPropertyValue("elasticsearch.write.type");
        readIndex = prop.getPropertyValue("elasticsearch.read.index");
        prop = EtilizeAnalyticsProperties.getInstance();

        transportPort = Integer.parseInt(prop.getPropertyValue("elasticsearch.transportport"));
        httpPort = Integer.parseInt(prop.getPropertyValue("elasticsearch.httpport"));
        clusterName = prop.getPropertyValue("elasticsearch.clusterName");
        serverUrl = prop.getPropertyValue("elasticsearch.serverUrl");
        settings = ImmutableSettings.settingsBuilder().put("cluster.name", clusterName).build();
        esTransportClient = new TransportClient(settings)
                .addTransportAddress(new InetSocketTransportAddress(serverUrl, transportPort));
        writeIndex = prop.getPropertyValue("elasticsearch.write.index");
        fetchQuery = prop.getPropertyValue("update.fetchQuery");

        configuration = new Configuration();
        logger.info("Total Properties : " + EtilizeAnalyticsProperties.getInstance().getProperties().size());
        for (Entry<String, String> property : EtilizeAnalyticsProperties.getInstance().getProperties().entrySet()) {
            logger.info("Property ===>" + property.getKey() + " Value =>" + property.getValue());
            if (property.getKey().startsWith(esConfigurationPrefix)) {

                configuration.set(property.getKey().replace(esConfigurationPrefix + ".", ""), property.getValue());
            }
        }
        configuration.setBoolean("mapred.map.tasks.speculative.execution", false);
        configuration.setBoolean("mapred.reduce.tasks.speculative.execution", false);
        logger.info(prop.getPropertyValue("ESConfiguration.es.nodes"));
    }

    public String getClusterName() {
        return clusterName;
    }

    public String getFetchQuery() {
        return fetchQuery;
    }

    public String getServerUrl() {
        return serverUrl;
    }

    public String getWriteIndex() {
        return writeIndex;
    }

    public Settings getSettings() {
        return settings;
    }

    public Client getESTransportClient() {
        return esTransportClient;
    }

    public String getReadType() {
        return readType;
    }

    public String getWriteType() {
        return writeType;
    }

    public String getReadIndex() {
        return readIndex;
    }

    public int getTransportPort() {
        return transportPort;
    }

    public int getHttpPort() {
        return httpPort;
    }

    /**
     * <p>
     * This function is used to close the ElasticSearch client
     * </p>
     */
    public void closeClient() {
        esTransportClient.close();
    }

    public Configuration getElasticSearchConfiguration() {
        return configuration;
    }
    //
    // private void loadElasticSearchConfiguration() {
    // final String configurationPrefix = "ESConfiguration";
    // // for(Object prop : EtilizeAnalyticsProperties.)
    //
    // }
}