package com.etilize.inquire;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.etilize.analytics.EtilizeAnalyticsProperties;
import com.etilize.analytics.bean.Domain;
import com.etilize.analytics.bean.ParamValue;
import com.etilize.analytics.bean.Parameter;
import com.etilize.analytics.dao.DomainParameterInfoDAO;
import com.etilize.analytics.data.DocumentData;
import com.etilize.analytics.data.DomainParameterInfoBean;
import com.etilize.analytics.data.ESSearchRequest;
import com.etilize.analytics.data.ESSearchResponse;
import com.etilize.elasticsearch.ESReader;
import com.etilize.elasticsearch.ESSettings;
import com.etilize.inquire.data.action.KeywordLoader;
import com.etilize.inquire.data.action.LuceneTokenizer;
import com.etilize.inquire.data.util.Utils;

/***
 * Class to process domain and queryStrings for that domain to identify names of
 * parameters used as keyword search Split queryString to get key/value pairs
 * (parametername and its value) for each parameter name, tokenize and stem
 * value match stemmed values to list of keywords, if it matches, give score of
 * 1 to that parameter scores needs to b maintained for all values or specific
 * parameter as well as unique values store both types of scores so that they
 * can be compared in order to identify keywords search by humans
 */
public class ParameterIdentifier {

    private static final Logger LOG = LoggerFactory.getLogger(ParameterIdentifier.class);

    private final static String FIELD_WEB_URL = EtilizeAnalyticsProperties.getProperty("parameteridentifier.weburl");
    private final static String FIELD_REQUEST_PARAMETERS = EtilizeAnalyticsProperties
            .getProperty("parameteridentifier.fieldRequestParameter");
    private final static int DOCUMENT_THRESHOLD = EtilizeAnalyticsProperties
            .getIntProperty("parameteridentifier.document.threshold", 0);
    static Set<String> keywords = KeywordLoader.loadKeywords();

    /**
     * Get domains that has to be processed for Keywords extraction
     */
    public static List<Domain> populateDomains() {
        List<Domain> domainsFromES = getDomainsFromES();

        // Get domains from database that are already processed for scores
        // Set<String> processedDomains =
        // DomainParameterInfoDAO.getAllDomains();

        // Subtract processed domains from Elasticsearch domains list
        // domainsFromES.removeAll(processedDomains);

        LOG.info("No of domains to be processed: " + domainsFromES.size());

        return domainsFromES;
    }

    /**
     * Get domains from ElasticSearch
     */
    public static List<Domain> getDomainsFromES() {
        List<Domain> domains = new ArrayList<Domain>();

        List<String> aggParams = new ArrayList<String>();
        aggParams.add(FIELD_WEB_URL);
        ESSearchRequest request = new ESSearchRequest(ESSettings.INSTANCE.getReadIndex(), aggParams);
        // TODO move this size to some property
        // request.setSize(EtilizeAnalyticsProperties.getIntProperty(
        // "elasticsearch.query.size", 0));
        ESSearchResponse response = ESReader.getAggregationResponse(request);
        Map<String, Long> aggregatedData = response.getAggregatedData();
        for (Entry<String, Long> data : aggregatedData.entrySet()) {
            // TODO decide threshold for doc count if domain is eligible for
            // processing and set this value in some prop
            // if (aggregatedData.get(key) > DOCUMENT_THRESHOLD)
            {
                Domain domain = new Domain();
                domain.setValue(data.getKey());
                domain.setCount(data.getValue());
                domains.add(domain);

            }
        }

        LOG.info("Retrieved domains from ElasticSearch: " + domains.size());
        return domains;
    }

    /**
     * Get documents from ElasticSearch for given domains
     */
    public static List<Domain> getDomainDocuments(List<Domain> domains) {

        List<String> fields = new ArrayList<String>();
        fields.add(FIELD_REQUEST_PARAMETERS);

        int i = 1;
        for (Domain domain : domains) {
            LOG.info("Retrieving documents for : " + domain.getValue());
            List<String> requestParameters = new ArrayList<String>();
            Map<String, String> filters = new HashMap<String, String>();
            filters.put(FIELD_WEB_URL, domain.getValue());

            ESSearchRequest scanRequest = new ESSearchRequest(ESSettings.INSTANCE.getReadIndex());
            scanRequest.setFilters(filters);
            // scanRequest.setSize(EtilizeAnalyticsProperties.getIntProperty(
            // "elasticsearch.query.size", 0));
            scanRequest.setSize(50);
            scanRequest.setFields(fields);
            scanRequest.setTimeOut(3000);
            ESSearchResponse scanResponse = ESReader.getScanResponse(scanRequest);
            String scrollId = scanResponse.getScrollId();

            ESSearchRequest request = new ESSearchRequest();
            request.setScrollId(scrollId);
            request.setTimeOut(3000);

            ESSearchResponse response = ESReader.getScrollResponse(request);

            Date date1 = new Date();
            for (DocumentData doc : response.getDocumentData().values()) {
                requestParameters.add(doc.getFields().get(FIELD_REQUEST_PARAMETERS));
            }

            // requestParameters.clear();
            //
            // date1 = new Date();
            // for (String docId : response.getDocumentData().keySet()) {
            // DocumentData doc = response.getDocumentData().get(docId);
            // for (String field : doc.getFields().keySet()) {
            // if (field.equalsIgnoreCase(FIELD_REQUEST_PARAMETERS)) {
            // requestParameters.add(doc.getFields().get(field));
            // }
            // }
            // }
            // date2 = new Date();
            // diff = Math.abs(date2.getTime() - date1.getTime());
            // diffDays = diff / (24 * 60 * 60 * 1000);
            // LOG.info("Time Code 2 : " + diffDays);
            domain.setParameters(populateDomainParamters(requestParameters));
            Date date2 = new Date();
            LOG.info("Loop Time : " + String.valueOf(((date2.getTime() - date1.getTime()) / 1000)));
            LOG.info("No of Parameters for " + domain.getValue() + " : " + domain.getParameters().size());
            LOG.info("Domains Processed : " + (i++) + " Out Of : " + domains.size());

        }
        return domains;
    }

    /**
     * 
     * @param queryString
     * @param parameterTokensMap
     *            with key as parameter name and value as collection of tokens
     *            for that parameter
     * @return
     */
    public static List<Parameter> populateDomainParamters(List<String> requestParameters) {
        HashMap<String, Parameter> parameters = new HashMap<String, Parameter>();
        double percentage = 0;
        int i = 1;
        try {
            for (String requestParameter : requestParameters) {
                // percentage = (i) * 100.0 / requestParameter.length();
                // LOG.info("Proccessed : " + i + " out of : "
                // + requestParameters.size());
                // i++;
                requestParameter = Utils.cleanQueryString(requestParameter);
                if (requestParameter != null) {
                    HashMap<String, String> parameterNameValueMap = Utils.getKeyValuesFromQueryString(requestParameter);
                    Parameter parameter;
                    for (String parameterName : parameterNameValueMap.keySet()) {

                        if (parameterNameValueMap.get(parameterName) != null) {
                            if (!parameters.containsKey(parameterName)) {
                                parameter = new Parameter(parameterName, 1);
                            } else {
                                parameter = parameters.get(parameterName);
                            }
                            parameter.setCount(parameter.getCount() + 1);
                            String paramValue = Utils.decode(parameterNameValueMap.get(parameterName));
                            // LOG.info("Parameter : " + parameterName
                            // + " Value : " + paramValue);
                            parameter.addFullParamValue(paramValue);

                            Set<String> tokens = LuceneTokenizer.tokenize(parameterNameValueMap.get(parameterName));
                            if (tokens != null) {
                                for (String token : tokens) {
                                    parameter.addTokenizeParamValue(token);
                                }
                            }
                            parameters.put(parameterName, parameter);
                        }
                    }
                }
            }
        } catch (Exception ex) {
            LOG.error(ex.getMessage());
        }
        return new ArrayList<Parameter>(parameters.values());
    }

    public static double getRatio(long documentCount, int cardinality, long domainDocumentCount) {
        double ratio = 0.0;
        ratio = (documentCount * 1.0 * cardinality / domainDocumentCount);
        return ratio;
    }

    public static void insertToDatabase(List<Domain> domains) {

        for (Domain domain : domains) {
            for (Parameter parameter : domain.getParameters()) {
                if (parameter.getKey().equals("q") && domain.getValue().contains("www.gsaadvantage.gov")) {
                    LOG.info("Infinity Case");
                }
                StringBuilder tokenizeValues = new StringBuilder();
                StringBuilder fullValues = new StringBuilder();
                DomainParameterInfoBean bean = new DomainParameterInfoBean();
                bean.setDomain(domain.getValue());
                bean.setParameterName(parameter.getKey());
                bean.setTotalDocument(parameter.getCount());
                bean.setTotalDomainDocument(domain.getCount());
                for (ParamValue paramValue : parameter.getTokenizeValues()) {
                    if (keywords.contains(paramValue.getValue().toLowerCase())) {
                        bean.setTokenizeParamCardinality(bean.getTokenizeParamCardinality() + 1);
                        bean.setScore(paramValue.getCount() + bean.getScore());
                        tokenizeValues.append(paramValue.getValue());
                        tokenizeValues.append("#");
                    }
                }
                for (ParamValue paramValue : parameter.getFullValues()) {
                    String values[] = paramValue.getValue().split(" ");
                    for (String value : values) {
                        if (keywords.contains(value.toLowerCase())) {
                            bean.setFullParamCardinality(bean.getFullParamCardinality() + 1);
                            bean.setScore(paramValue.getCount() + bean.getScore());
                            fullValues.append(paramValue.getValue());
                            fullValues.append("#");
                            break;
                        }
                    }
                }

                if (bean.getFullParamCardinality() > 0 || bean.getTokenizeParamCardinality() > 0) {

                    bean.setTokenizeParamRatio(getRatio(bean.getTotalDocument(), bean.getTokenizeParamCardinality(),
                            bean.getTotalDomainDocument()));
                    bean.setFullParamRatio(getRatio(bean.getTotalDocument(), bean.getFullParamCardinality(),
                            bean.getTotalDomainDocument()));

                    bean.setFullParamValues(fullValues.toString());
                    bean.setTokenizeParamValues(tokenizeValues.toString());

                    DomainParameterInfoDAO.insertDomainParameterScores(bean);
                }
            }
        }

    }

}
