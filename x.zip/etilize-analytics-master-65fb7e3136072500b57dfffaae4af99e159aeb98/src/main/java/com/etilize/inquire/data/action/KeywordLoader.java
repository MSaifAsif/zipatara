package com.etilize.inquire.data.action;

import java.util.Set;

import org.junit.Assert;
import org.junit.Test;

import com.etilize.analytics.dao.StemmedWordsDAO;

public enum KeywordLoader {
    INSTANCE;

    private KeywordLoader() {
    }

    public static Set<String> loadKeywords() {
        return StemmedWordsDAO.getAllKeywords();
    }

    @Test
    public void testLoadKeywords() {
        Set<String> keywords = loadKeywords();
        System.out.println(keywords.size());
        Assert.assertEquals(11752, keywords.size());
    }
}
