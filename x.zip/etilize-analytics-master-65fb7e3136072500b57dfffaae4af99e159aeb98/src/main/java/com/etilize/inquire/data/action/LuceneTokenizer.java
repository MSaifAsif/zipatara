package com.etilize.inquire.data.action;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.HashSet;
import java.util.Set;

import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.core.LetterTokenizer;
import org.apache.lucene.analysis.core.LowerCaseFilter;
import org.apache.lucene.analysis.core.WhitespaceTokenizer;
import org.apache.lucene.analysis.en.PorterStemFilter;
import org.apache.lucene.analysis.shingle.ShingleFilter;
import org.apache.lucene.analysis.standard.StandardFilter;
import org.apache.lucene.analysis.standard.StandardTokenizer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.util.Version;

public class LuceneTokenizer {

    public static Set<String> tokenize(String value) {
        Set<String> tokens = new HashSet<String>();
        tokens.addAll(getSimpleTokens(value));
        tokens.addAll(getWhiteSpaceTokens(value));
        tokens.addAll(getAlphabetTokens(value));
        return tokens;

    }

    @SuppressWarnings("deprecation")
    public static Set<String> getSimpleTokens(String value) {
        StringReader reader = new StringReader(value);
        Tokenizer tokenizer = new StandardTokenizer(Version.LUCENE_CURRENT, reader);

        Set<String> tokens = new HashSet<String>();
        TokenStream tokenStream = new StandardFilter(Version.LUCENE_CURRENT, tokenizer);
        tokenStream = new LowerCaseFilter(Version.LUCENE_CURRENT, tokenStream);
        tokenStream = new PorterStemFilter(tokenStream);

        final CharTermAttribute charTermAttribute = tokenizer.addAttribute(CharTermAttribute.class);

        try {
            tokenStream.reset();
            while (tokenStream.incrementToken()) {
                final String token = charTermAttribute.toString().toString();

                if (token.length() > 1) {
                    tokens.add(token);
                }
            }
            tokenStream.close();
        } catch (IOException e) {
            e.printStackTrace();
            return tokens;
        }
        return tokens;
    }

    @SuppressWarnings("deprecation")
    public static Set<String> getWhiteSpaceTokens(String value) {
        StringReader reader = new StringReader(value);
        Tokenizer tokenizer = new WhitespaceTokenizer(Version.LUCENE_CURRENT, reader);

        Set<String> tokens = new HashSet<String>();
        TokenStream tokenStream = new StandardFilter(Version.LUCENE_CURRENT, tokenizer);
        tokenStream = new LowerCaseFilter(Version.LUCENE_CURRENT, tokenStream);
        tokenStream = new PorterStemFilter(tokenStream);

        final CharTermAttribute charTermAttribute = tokenizer.addAttribute(CharTermAttribute.class);

        try {
            tokenStream.reset();
            while (tokenStream.incrementToken()) {
                final String token = charTermAttribute.toString().toString();

                if (token.length() > 1) {
                    tokens.add(token);
                }
            }
            tokenStream.close();
        } catch (IOException e) {
            e.printStackTrace();
            return tokens;
        }
        return tokens;
    }

    @SuppressWarnings("deprecation")
    public static Set<String> getAlphabetTokens(String value) {
        StringReader reader = new StringReader(value);
        Tokenizer tokenizer = new LetterTokenizer(Version.LUCENE_CURRENT, reader);

        Set<String> tokens = new HashSet<String>();
        TokenStream tokenStream = new StandardFilter(Version.LUCENE_CURRENT, tokenizer);
        tokenStream = new LowerCaseFilter(Version.LUCENE_CURRENT, tokenStream);
        tokenStream = new PorterStemFilter(tokenStream);

        final CharTermAttribute charTermAttribute = tokenizer.addAttribute(CharTermAttribute.class);

        try {
            tokenStream.reset();
            while (tokenStream.incrementToken()) {
                final String token = charTermAttribute.toString().toString();
                if (token.length() > 1) {
                    tokens.add(token);
                }
            }
            tokenStream.close();
        } catch (IOException e) {
            e.printStackTrace();
            return tokens;
        }
        return tokens;
    }

    public static Set<String> getNgramTokens(String value, int min, int max) {
        Set<String> tokens = new HashSet<String>();

        Reader reader = new StringReader(value);
        TokenStream tokenizer = new StandardTokenizer(Version.LATEST, reader);
        tokenizer = new ShingleFilter(tokenizer, 2, 3);
        CharTermAttribute charTermAttribute = tokenizer.addAttribute(CharTermAttribute.class);
        try {
            tokenizer.reset();
            while (tokenizer.incrementToken()) {
                final String token = charTermAttribute.toString().toString();
                if (token.length() > 1) {
                    tokens.add(token);
                }
            }
            tokenizer.end();
            tokenizer.close();

        } catch (IOException e) {
            e.printStackTrace();
            return tokens;
        }
        return tokens;

    }

}
