package com.etilize.inquire.data.action;

import java.util.HashSet;
import java.util.Set;

@Deprecated
public class OpenNLPTokenizer {

    public static Set<String> tokenize(String value) {
        Set<String> tokens = new HashSet<String>();
        tokens.addAll(getSimpleTokens(value));
        tokens.addAll(getWhiteSpaceTokens(value));
        return tokens;

    }

    public static Set<String> getSimpleTokens(String value) {
        Set<String> tokens = new HashSet<String>();
        /*
         * Tokenizer tokenizer = SimpleTokenizer.INSTANCE; String allTokens[] =
         * tokenizer.tokenize(value); for (String t : allTokens) { if(t.length()
         * > 1) { tokens.add(t); } }
         */
        return tokens;
    }

    public static Set<String> getWhiteSpaceTokens(String value) {
        Set<String> tokens = new HashSet<String>();
        /*
         * Tokenizer tokenizer = WhitespaceTokenizer.INSTANCE; String
         * allTokens[] = tokenizer.tokenize(value); for (String t : allTokens) {
         * if(t.length() > 1) { tokens.add(t); } }
         */
        return tokens;
    }
}
