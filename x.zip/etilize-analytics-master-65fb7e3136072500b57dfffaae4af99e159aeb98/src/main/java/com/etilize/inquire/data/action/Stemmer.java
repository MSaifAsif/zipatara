package com.etilize.inquire.data.action;

import org.tartarus.snowball.ext.PorterStemmer;

@Deprecated
public class Stemmer {

    private final static PorterStemmer stemmer = new PorterStemmer();

    public static String getPorterStem(String str) {
        stemmer.setCurrent(str);
        return stemmer.stem() == true ? stemmer.getCurrent() : str;
    }

}
