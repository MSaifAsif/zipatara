package com.etilize.inquire.data.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.HashSet;
import java.util.Set;

import com.etilize.inquire.data.action.KeywordLoader;
import com.etilize.inquire.data.action.LuceneTokenizer;

// class used to tokenize and stem words from wordnet files and write output to file
public class StemmerUtil {

    public static void main(String[] args) {
        stemWordsList();
    }

    public static void stemWordsList() {
        Set<String> keywords = KeywordLoader.INSTANCE.loadKeywords();
        Set<String> stemmedWords = new HashSet<String>();

        for (String word : keywords) {
            stemmedWords.addAll(LuceneTokenizer.tokenize(word));
        }

        System.out.println(stemmedWords.size());
        try {

            String filePath = "/home/farhatmajeed/stemmedWords.txt";
            File fout = new File(filePath);
            FileOutputStream fos = new FileOutputStream(fout);

            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
            for (String stem : stemmedWords) {
                bw.write(stem);
                bw.newLine();
            }
            bw.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
