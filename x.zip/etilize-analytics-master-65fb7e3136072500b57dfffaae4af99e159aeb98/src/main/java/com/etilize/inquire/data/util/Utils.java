package com.etilize.inquire.data.util;

import java.net.URLDecoder;
import java.util.HashMap;

public class Utils {

    public static String decodeURL(String url) {
        try {
            return URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {
            return url;
        }
    }

    // helper to decode URL for removal of +sign and other data from queryString
    public static String cleanQueryString(String queryString) {
        String[] requestParameters = queryString.split("\\?");
        return requestParameters.length > 1 ? requestParameters[1].replaceAll("\\+", " ") : null;
    }

    // get parameter names and values separated by =sign and all key/value pairs
    // separated by &sign
    public static HashMap<String, String> getKeyValuesFromQueryString(String queryString) {
        HashMap<String, String> parameterNameValueMap = new HashMap<String, String>();
        String[] parametersList = queryString.split("&");

        for (String kv : parametersList) {
            String[] data = kv.split("=");
            if (data.length > 0) {
                String paramName = data[0]; // parameter name
                String paramValue = data.length > 1 ? decodeURL(data[1]) : null; // parameter
                                                                                 // value
                parameterNameValueMap.put(paramName, paramValue);
            }
        }
        return parameterNameValueMap;
    }

    public static String decode(String str) {
        str = str.replaceAll("%(?![0-9a-fA-F]{2})", "%25");
        str = str.replaceAll("\\+", " ");
        str = str.replaceAll("\\\\", "");
        str = str.replaceAll("_+", " ");
        return str;
    }
}
