package com.etilize.redis;

import com.etilize.analytics.EtilizeAnalyticsProperties;

import redis.clients.jedis.Jedis;

public enum RedisClient {

    INSTANCE;
    public Jedis client;
    private EtilizeAnalyticsProperties prop;
    private String server;
    private int port;

    private RedisClient() {
        prop = EtilizeAnalyticsProperties.getInstance();
        server = prop.getPropertyValue("redis.server");
        port = Integer.parseInt(prop.getPropertyValue("redis.port"));
        client = new Jedis(server, port);

    }
}
