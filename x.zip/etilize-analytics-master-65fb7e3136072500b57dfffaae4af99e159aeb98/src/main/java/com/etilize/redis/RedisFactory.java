package com.etilize.redis;

import java.util.HashMap;

import redis.clients.jedis.Jedis;

public enum RedisFactory {
    INSTANCE;
    private HashMap<String, Jedis> clientMap;

    private RedisFactory() {
        clientMap = new HashMap<String, Jedis>();
    }

    public Jedis getClient(String server, int port) {
        int hash = server.hashCode() * port * 37;
        if (clientMap.containsKey(String.valueOf(hash))) {
            return clientMap.get(hash);
        } else {
            Jedis client = new Jedis(server, port);
            clientMap.put(String.valueOf(hash), client);
            return client;
        }
    }
}
