package com.etilize.redis;

/**
 * <p>
 * This class contains Redis settings related to product data and delete document server
 * </p>
 * <br/>
 * <p>
 * Redis configurations should be given at
 * EtilizeAnalytics.properties
 * </p>
 */

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.etilize.analytics.EtilizeAnalyticsProperties;

public enum RedisSettings {
    INSTANCE;
    private Logger logger;
    private int productDataPort, deleteDocumentPort;
    private String productDataServer, deleteDocumentServer, redisDeleteList, productDataField;
    private EtilizeAnalyticsProperties prop;

    private RedisSettings() {
        logger = LoggerFactory.getLogger(RedisSettings.class);
        prop = EtilizeAnalyticsProperties.getInstance();
        productDataServer = prop.getPropertyValue("productData.redis.server");
        deleteDocumentServer = prop.getPropertyValue("removeDocuments.redis.server");
        productDataPort = Integer.parseInt(prop.getPropertyValue("productData.redis.port"));
        deleteDocumentPort = Integer.parseInt(prop.getPropertyValue("removeDocuments.redis.port"));
        redisDeleteList = prop.getPropertyValue("redis.removeIds.deleteList");
        productDataField = prop.getPropertyValue("productData.redis.productFields");
        logger.info("Redis properties loaded");
    }

    public String getRedisDeleteList() {
        return redisDeleteList;
    }

    public int getProductDataPort() {
        return productDataPort;
    }

    public int getDeleteDocumentPort() {
        return deleteDocumentPort;
    }

    public String getProductDataServer() {
        return productDataServer;
    }

    public String getDeleteDocumentServer() {
        return deleteDocumentServer;
    }

    public String getProductDataField() {
        return productDataField;
    }

}
