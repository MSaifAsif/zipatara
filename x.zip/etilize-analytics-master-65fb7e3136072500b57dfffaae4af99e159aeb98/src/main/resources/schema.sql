CREATE DATABASE `EtilizeAnalytics`

CREATE TABLE `stemmed_words` (
  `word` varchar(80) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8

CREATE TABLE `SearchAttributes` (
  `WebURL` varchar(50) NOT NULL,
  `parameterKey` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;