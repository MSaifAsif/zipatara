CREATE DATABASE `dictionary`

CREATE TABLE `stemmed_words` (
  `word` varchar(80) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8
