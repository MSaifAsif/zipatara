package com.etilize.elasticsearch.hadoop.junit.test;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.elasticsearch.hadoop.mr.LinkedMapWritable;
import org.junit.Test;

import com.etilize.analytics.parser.UrlParser;

public class ESUpdateTest {

 //   @Test
    public void functionalityTest() throws JsonParseException, JsonMappingException, IOException {
        // String jsonString = "{\"specs1\":\"Testing\",\"specs2\":\"300\",\"specs3\":\"BABWUR1100E14\"}";
        LinkedMapWritable map = new LinkedMapWritable();
        map.put(new Text("product_id"), new Text("10289194"));
        map.put(new Text("rc_type"), new Text("310"));
        map.put(new Text("manufacturer_part_no.raw"), new Text("BABWUR1100E14"));
        map.put(new Text("category_id"), new Text("51053"));
        map.put(new Text("category_name.raw"), new Text("(null)"));
        map.put(new Text("manufacturer_id"), new Text("10344"));
        map.put(new Text("manufacturer_name.raw"), new Text("CA Technologies"));
        map.put(new Text("country_code.raw"), new Text("USA"));
        map.put(new Text("country.raw"), new Text("United States"));
        map.put(new Text("region_code.raw"), new Text("NC"));
        map.put(new Text("city.raw"), new Text("Charlotte"));
        map.put(new Text("region_name.raw"), new Text("North Carolina"));

        // ESUpdate esUpdate = new ESUpdate("id", map);
        //
        // //esUpdate.updateFields("rc_type", "215");
        // //System.out.println(esUpdate.getJsonDoc().toString());
        //
        // // esUpdate.removeFieldByName("rc_type");
        // // System.out.println(esUpdate.getJsonDoc().toString());
        //
        // // esUpdate.regexReplace("10", "Te");
        // // System.out.println(esUpdate.getJsonDoc().toString());
        //
        // // esUpdate.removeEmptyfields();
        // // System.out.println(esUpdate.getJsonDoc().toString());
        //
        // // esUpdate.renameField("product_id", "product_id.raw");
        // // System.out.println(esUpdate.getJsonDoc().toString());
        //
        // esUpdate.updateProductData();
        // System.out.println(esUpdate.getJsonDoc().toString());

    }

    @Test
    public void loadDomain() {
        UrlParser parser = UrlParser.INTSANCE;
    }
}
