package com.etilize.elasticsearch.junit.tests;

import org.junit.Test;

public class NullFieldIdentifierTest {

    @Test
    public void testNullFieldIdentifier() {
        /*
         * EtilizeAnalyticsProperties prop = EtilizeAnalyticsProperties
         * .getInstance();
         * 
         * ESUpdate esupdate = new ESUpdate("_X-O8hzdQCGyun57OCbo1g", null);
         * esupdate.updateProductData(); String replaceFieldNames = (prop
         * .getPropertyValue("elasticsearch.replaceFieldNames"));
         * 
         * 
         * String assertedResult = ""; String jsonString = "";/*
         * "{product_id=(null), rc_type=300, description=MCE Technologies Auto Adapter, "
         * +
         * "category_id=10028, manufacturer_id=103148, specs={brand_name=MCE Technologies, product_type=Auto Adapter, product_line=(null), "
         * +
         * " series=(null), moreSpecs={specs1=(null),MuchSpecs={spex=(null)}}}, country_code.raw=USA, country.raw=United States, region_code.raw=NC, city.raw=Charlotte, "
         * +
         * " region_name.raw=North Carolina, category_name.raw=Power Adapters, manufacturer_name.raw=MCE Technologies, LLC, manufacturer_part_no.raw=AUTO\\/G3-X400}"
         * ; assertedResult =
         * ",description specs,brand_name specs.moreSpecs,manufacturer_name.raw"
         * ; System.out.println(StringUtils.join(
         * esupdate.getFieldNames(jsonString, "MCE Technologies"), " "));
         * assertEquals(assertedResult, StringUtils.join(
         * esupdate.getFieldNames(jsonString, "MCE Technologies"), " "));
         */
        /*
         * jsonString =
         * "{product_id=(null),rc_type=300,description=MCETechnologiesAutoAdapter,category_id=10028,manufacturer_id=(null),specs={brand_name=MCETechnologies,product_type=AutoAdapter,product_line=(null),series=(null),moreSpecs={specs1=(null),MuchSpecs1={spex=(null),MuchSpecs2={spex=(null),MuchSpecs3={spex=(null),MuchSpecs4={spex=(null)}}}}}},country_code.raw=USA,country.raw=UnitedStates,region_code.raw=NC,city.raw=Charlotte,region_name.raw=NorthCarolina,category_name.raw=PowerAdapters,manufacturer_name.raw=MCE Technologies,LLC,manufacturer_part_no.raw=AUTO\\/G3-X400}"
         * ; assertedResult =
         * ",product_id ,manufacturer_id specs,product_line specs,series specs.moreSpecs,specs1 "
         * + "specs.moreSpecs.MuchSpecs1,spex " +
         * "specs.moreSpecs.MuchSpecs1.MuchSpecs2,spex " +
         * "specs.moreSpecs.MuchSpecs1.MuchSpecs2.MuchSpecs3,spex " +
         * "specs.moreSpecs.MuchSpecs1.MuchSpecs2.MuchSpecs3.MuchSpecs4,spex";
         * // System.out.println(StringUtils.join( //
         * esupdate.getFieldNames(jsonString, "Technolo"), " ")); //
         * esupdate.replaceFieldNames(replaceFieldNames);
         * 
         * /*assertEquals( assertedResult, StringUtils.join(
         * esupdate.getFieldNames(jsonString, "\\(null\\)"), " "));
         */

    }

}
