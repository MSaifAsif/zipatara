/*
 * package com.etilize.inquire.junit.tests;
 * 
 * import org.junit.Test;
 * 
 * import com.carrotsearch.junitbenchmarks.AbstractBenchmark; import
 * com.carrotsearch.junitbenchmarks.BenchmarkOptions;
 * 
 * public class ConcetenateVsHashCode extends AbstractBenchmark { static String
 * server = "server.com"; static int port = 6380;
 * 
 * @BenchmarkOptions(benchmarkRounds = 10000000, warmupRounds = 15)
 * 
 * @Test public void concatenate() { //String server = "server.com"; //String
 * port = "6380"; StringBuilder sb = new StringBuilder(); sb.append(server);
 * sb.append(port); sb.toString(); }
 * 
 * 
 * @BenchmarkOptions(benchmarkRounds = 10000000, warmupRounds = 15)
 * 
 * @Test public void hash() {
 * 
 * int hashCode = server.hashCode() * port * 37; } }
 */