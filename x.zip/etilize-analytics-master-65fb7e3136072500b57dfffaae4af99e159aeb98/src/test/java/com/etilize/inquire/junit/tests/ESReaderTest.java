// package com.etilize.inquire.junit.tests;
//
// import static org.junit.Assert.*;
//
// import java.util.ArrayList;
// import java.util.HashMap;
// import java.util.List;
// import java.util.Map;
//
// import org.junit.Test;
//
// import com.etilize.analytics.data.ESSearchRequest;
// import com.etilize.analytics.data.ESSearchResponse;
// import com.etilize.elasticsearch.ESSettings;
// import com.etilize.elasticsearch.ESReader;
//
//
// public class ESReaderTest {
//
// String scrollId;
//
// @Test
// public void testGetAggregationResponse() {
// List<String> aggParams = new ArrayList<String>();
// aggParams.add("web_url");
// ESSearchRequest request = new
// ESSearchRequest(ESSettings.INSTANCE.getReadIndex(), aggParams);
// request.setSize(3);
// ESSearchResponse response = ESReader.getAggregationResponse(request);
// Map<String, Long> result = response.getAggregatedData();
// for(String key : result.keySet())
// System.out.println("*************" + key);
// assertEquals(3, result.size());
// }
//
// @Test
// public void testGetScanResponse() {
// List<String> fields = new ArrayList<String>();
// fields.add("request_parameters");
//
// Map<String, String> filters = new HashMap<String, String>();
// filters.put("web_url", "www.imstores.com");
//
// ESSearchRequest request = new
// ESSearchRequest(ESSettings.INSTANCE.getReadIndex());
// request.setFilters(filters);
// request.setSize(200);
// request.setFields(fields);
// request.setTimeOut(3000);
// ESSearchResponse response = ESReader.getScanResponse(request);
// scrollId = response.getScrollId();
// System.out.println("***********"+scrollId);
//
// testGetScrollResponse();
// }
//
// //@Test
// public void testGetScrollResponse() {
// ESSearchRequest request = new ESSearchRequest();
// request.setScrollId(scrollId);
// request.setTimeOut(3000);
//
// ESSearchResponse response = ESReader.getScrollResponse(request);
// System.out.println("******** " + response.getDocumentData().size());
//// for(String docId: response.getDocumentData().keySet()) {
//// DocumentData doc = response.getDocumentData().get(docId);
//// for(String field : doc.getFields().keySet())
//// System.out.println("*********** "+ field + ": " +
// doc.getFields().get(field));
////
//// }
// }
//
// }
