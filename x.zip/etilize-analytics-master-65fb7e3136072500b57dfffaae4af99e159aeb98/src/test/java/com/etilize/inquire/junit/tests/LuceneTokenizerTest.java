package com.etilize.inquire.junit.tests;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.Set;

import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.core.SimpleAnalyzer;
import org.apache.lucene.analysis.ngram.NGramTokenizer;
import org.apache.lucene.analysis.shingle.ShingleAnalyzerWrapper;
import org.apache.lucene.analysis.shingle.ShingleFilter;
import org.apache.lucene.analysis.standard.StandardTokenizer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.util.Version;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestRule;

//import com.carrotsearch.junitbenchmarks.BenchmarkOptions;
//import com.carrotsearch.junitbenchmarks.BenchmarkRule;
import com.etilize.inquire.data.action.LuceneTokenizer;

public class LuceneTokenizerTest {

    // @Rule
    // public TestRule benchmarkRun = new BenchmarkRule();

    // @BenchmarkOptions(benchmarkRounds = 2, warmupRounds = 0)
    // @Test
    public void testTokenize() {
        String value = "44:2Cable\\+pedestal";
        Set<String> tokens = LuceneTokenizer.tokenize(value);
        for (String t : tokens) {
            System.out.println(t);
        }
    }

    // @BenchmarkOptions(benchmarkRounds = 2, warmupRounds = 0)
    // @Test
    public void testGetSimpleTokens() {
        String value = "44:2Cable\\+pedestal";
        Set<String> tokens = LuceneTokenizer.getSimpleTokens(value);
        for (String t : tokens) {
            System.out.println(t);
        }
    }

    // @Test
    public void testGetWhiteSpaceTokens() {
        String value = "44:2Cable\\+pedestal";
        Set<String> tokens = LuceneTokenizer.getWhiteSpaceTokens(value);
        for (String t : tokens) {
            System.out.println(t);
        }
    }

    // @Test
    public void testGetAlphabetsTokens() {
        String value = "44:2Cable\\+pedestal";
        Set<String> tokens = LuceneTokenizer.getAlphabetTokens(value);
        for (String t : tokens) {
            System.out.println(t);
        }
    }

    @Test
    public void testGetNgramTokens() {
        String value = "printers and monitors hp";
        Set<String> tokens = LuceneTokenizer.getNgramTokens(value, 1, 5);
        for (String t : tokens) {
            System.out.println(t);
        }
    }

}