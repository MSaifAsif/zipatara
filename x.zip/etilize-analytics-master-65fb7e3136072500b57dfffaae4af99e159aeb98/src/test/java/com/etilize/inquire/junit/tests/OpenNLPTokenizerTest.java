package com.etilize.inquire.junit.tests;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Set;

import org.junit.Test;

import com.etilize.inquire.data.action.OpenNLPTokenizer;

@SuppressWarnings("deprecation")
public class OpenNLPTokenizerTest {

    // @Test
    public void testGetTokens() {
        String rp = "/advantage/s/search.do?q=44:2Cable\\+pedestal&db=65&searchType=81";
        try {
            rp = URLDecoder.decode(rp, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        String queryString = rp.split("\\?")[1].replaceAll("\\\\", "");
        ;
        System.out.println(queryString);
        String[] keyValues = queryString.split("&");

        for (String kv : keyValues) {
            String[] data = kv.split("=");
            String paramName = data[0];
            String paramValue = data[1];
            System.out.println(paramName + "::::" + paramValue);

            // tokens.addAll(testSimpleTokenizer(paramValue));

            System.out.println("===========SIMPLE TOKENS===========");
            testSimpleTokenizer(paramValue);
            System.out.println("===========WHITE SPACE TOKENS===========");
            testWhiteSspaceTokenizer(paramValue);
            // System.out.println("===========PARTNO TOKENS===========");
            // testPartNoTokenizer(paramValue);
        }
    }

    public void testSimpleTokenizer(String value) {
        Set<String> tokens = OpenNLPTokenizer.getSimpleTokens(value);
        for (String t : tokens) {
            System.out.println(t);
        }
    }

    public void testWhiteSspaceTokenizer(String value) {
        Set<String> tokens = OpenNLPTokenizer.getWhiteSpaceTokens(value);
        for (String t : tokens) {
            System.out.println(t);
        }
    }

    @Test
    public void testString() {
        String str1 = "MyName";
        String str2 = new String("MyName");
        String str3 = str2;

        if (str1 == str2) {
            System.out.println("Objects are equal");
        } else {
            System.out.println("Objects are not equal");
        }
        if (str1.equals(str2)) {
            System.out.println("Objects are equal");
        } else {
            System.out.println("Objects are not equal");
        }
    }
    /*
     * public void testPartNoTokenizer(String value) { Set<String> tokens =
     * com.etilize.inquire.data.action.OpenNLPTokenizer.getPartNoTokens(value);
     * for(String t : tokens) { System.out.println(t); } }
     */
}
