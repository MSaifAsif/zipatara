package com.etilize.inquire.junit.tests;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.carrotsearch.junitbenchmarks.BenchmarkOptions;
import com.etilize.analytics.bean.Domain;
import com.etilize.inquire.ParameterIdentifier;

public class ParameterIdentifierTest {

    // @Rule
    // public TestRule benchmarkRun = new BenchmarkRule();
    // HashMap<String, List<String>> urlAndQueryStringMap;

    @Before
    public void testGetDataForParameterIdentification() {
        try {
            // urlAndQueryStringMap = ParameterIdentifier
            // .getDataForParameterIdentification();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    // /@BenchmarkOptions(benchmarkRounds = 1, warmupRounds = 0)
    // @Test
    // public void testParamIdentifier() {
    //
    // // List<Domain> domains = ParameterIdentifier.getDomainsFromES();
    // List<Domain> domains = new ArrayList<Domain>();
    // Domain domain = new Domain();
    // domain.setValue("www.gsaadvantage.gov");
    // domains.add(domain);
    // ParameterIdentifier.getDomainDocuments(domains);
    // ParameterIdentifier.insertToDatabase(domains);
    //
    // }
    @BenchmarkOptions(benchmarkRounds = 1, warmupRounds = 0)
    @Test
    public void testGetDomainsFromES() {
        List<Domain> domains = ParameterIdentifier.populateDomains();
        // List<Domain> domains = new ArrayList<Domain>();
        // Domain domain = new Domain();
        // domain.setValue("www.gsaadvantage.gov");
        // domain.setCount(228220);
        // domains.add(domain);
        ParameterIdentifier.getDomainDocuments(domains);
        ParameterIdentifier.insertToDatabase(domains);
    }
}
