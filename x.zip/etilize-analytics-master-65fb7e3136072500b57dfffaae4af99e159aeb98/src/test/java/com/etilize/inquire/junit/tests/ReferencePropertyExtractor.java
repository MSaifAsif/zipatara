package com.etilize.inquire.junit.tests;

import com.etilize.analytics.EtilizeAnalyticsProperties;

public class ReferencePropertyExtractor {

    public static void main(String args[]) {

        try {
            EtilizeAnalyticsProperties etilizeAnalyticsProperties = EtilizeAnalyticsProperties.getInstance();
            System.out.println(etilizeAnalyticsProperties.getPropertyValue("test1"));
            System.out.println(etilizeAnalyticsProperties.getPropertyValue("test2"));
            System.out.println(etilizeAnalyticsProperties.getPropertyValue("test3"));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
}
